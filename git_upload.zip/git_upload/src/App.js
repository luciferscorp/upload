import React, { useEffect, useState } from "react";
import {
  createBrowserRouter,
  RouterProvider,
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";

import Home from "./components/screen/Home/Home.js";
import RegisterPage from "./components/screen/Register/Register.js";
import LoginPage from "./components/screen/Login/Login.js";

import Admin from "./components/screen/Admin/Admin.js";
import Assign from "./components/screen/Assign/Assign.js";
import Employee from "./components/screen/Employee/Employee.js";
import Company from "./components/screen/Company/Company.js";
import ProjectManager from "./components/screen/ProjectManager/ProjectManager.js";
import Projects from "./components/screen/Projects/Projects.js";
import Tasks from "./components/screen/Tasks/Tasks.js";
import Test from "./components/screen/Test/Test.js";
import Logout from "./components/common/Logout.js";
import TaskEmployee from "./components/screen/TaskEmployee/TaskEmployee.js";
import Loading from "./components/common/Loading.js";
import PrivateRoute from "./components/auth/PrivateRoute.js";
import DashBoard from "./components/screen/Admin/Dashboard.js";
import '../src/App.css'
import LeaderProject from "./components/screen/LeaderProject/LeaderProject.js";
import DashBoardPM from "./components/screen/ProjectManager/DashBoardPM.js";
import Notifications from "./components/common/Notifications.js";
import DashBoardPL from "./components/common/DashboardPL.js";
import DashBoardEM from "./components/common/DashBoardEM.js";
import Report from "./components/screen/Admin/Report.js";
import loadinggif from "../src/components/assets/images/loading.gif";
import Profile from "./components/screen/Profile/Profile.js";

function App() {
  const [isLoading, setIsLoading] = useState(true);
  function Error404() {
    return (
      <>
        <div>
          <h3>404 page not found</h3>
          <p>We are sorry but the page you are looking for does not exist.</p>
        </div>
      </>
    );
  }

  
  const routes = createBrowserRouter([
    {
      path: "/",
      element: <LoginPage />,
    },
    {
      path: "/login",
      element: <LoginPage />,
    },
    // {
    //   path: '*',
    //   element: <Error404 />

    // },
    {
      path: "/loading",
      element: <Loading />,
    },
    {
      path: "/home",
      element: <Home />,
    },

    {
      path: "/profile",
      element: <Profile />,
    },
    {
      path: "/admin",
      element: <Admin />,
    },
    {
      path: "/notifications",
      element: <Notifications />,
    },
    {
      path: "/dashboard",
      element: (
        <PrivateRoute UserRole={1}>
          <DashBoard />
        </PrivateRoute>
      ),
    },
    {
      path: "/report",
      element: (
        <PrivateRoute UserRole={1}>
          <Report />
        </PrivateRoute>
      ),
    },
    {
      path: "/employee",
      element: (
        <PrivateRoute UserRole={1}>
          <Employee />
        </PrivateRoute>
      ),
    },
    {
      path: "/company",
      element: (
        <PrivateRoute UserRole={1}>
          <Company />
        </PrivateRoute>
      ),
    },
    {
      path: "/dashboardPM",
      element: (
        <PrivateRoute UserRole={2}>
          <DashBoardPM />
        </PrivateRoute>
      ),
    },
    {
      path: "/projectmanager",
      element: (
        <PrivateRoute UserRole={2}>
          <ProjectManager />
        </PrivateRoute>
      ),
    },

    {
      path: "/projects",
      element: (
        <PrivateRoute UserRole={2}>
          <Projects />
        </PrivateRoute>
      ),
    },

    {
      path: "/assign",
      element: (
        <PrivateRoute UserRole={3}>
          <Assign />
        </PrivateRoute>
      ),
    },
    {
      path: "/leaderproject",
      element: (
        <PrivateRoute UserRole={3}>
          <LeaderProject />
        </PrivateRoute>
      ),
    },

    {
      path: "/tasks",
      element: (
        <PrivateRoute UserRole={3}>
          <Tasks />
        </PrivateRoute>
      ),
    },
    {
      path: "/dashboardpl",
      element: (
        <PrivateRoute UserRole={3}>
          <DashBoardPL />
        </PrivateRoute>
      ),
    },
    {
      path: "/dashboardEM",
      element: (
        <PrivateRoute UserRole={4}>
          <DashBoardEM />
        </PrivateRoute>
      ),
    },
    {
      path: "/employeetasks",
      element: (
        <PrivateRoute UserRole={4}>
          <TaskEmployee />
        </PrivateRoute>
      ),
    },
    {
      path: "/test",
      element: <Test />,
    },
    {
      path: "/logout",
      element: <Logout />,
    },
  ]);
  // This will run one time after the component mounts
  useEffect(() => {
    // callback function to call when event triggers
    const onPageLoad = () => {
      
      setTimeout(() => {
        setIsLoading(false);
      }, 2000);

      // do something else
    };

    // Check if the page has already loaded
    if (document.readyState === "complete") {
      onPageLoad();
    } else {
      window.addEventListener("load", onPageLoad, false);
      // Remove the event listener when component unmounts
      return () => window.removeEventListener("load", onPageLoad);
    }
  }, []);

  return (
    <>
      {isLoading ? (
        <div className="loading-container">
          <img src={loadinggif} alt="Loading..." className="loading-gif" />
        </div>
      ) : (
        <RouterProvider router={routes} />
      )}
    </>
  );
}

export default App;
