import { createContext, useState } from "react";
import dayjs from 'dayjs';


const AuthContext = createContext({});

export const AuthProvider = ({ children }) => {
    const [NotifyBadgeReadCount, setNotifyBadgeReadCount] = useState([]);
    const [NotificationID, setNotificationID] = useState([]);
    const [NotifyAssignEmpID, setNotifyAssignEmpID] = useState([]);
    const [NotifyAssignTaskNM, setNotifyAssignTaskNM] = useState([]);
    const [NotifyEMPname, setNotifyEMPname] = useState([]);
    const [DB_ProjectMGR_OpenTasks, setDB_ProjectMGR_OpenTasks] = useState([]);
    const [NavbarProfileImage, setNavbarProfileImage] = useState(null)
    const [isCompanyRecords, setisCompanyRecords] = useState(false);
    const [NotifyAssignedToEmployeeID, setNotifyAssignedToEmployeeID] = useState([]);
    const [DefaultValueOnTimer, setDefaultValueOnTimer] = useState(dayjs('2022-04-17T00:00:00'));

    

    return (
        <AuthContext.Provider value={{ 
            NotifyBadgeReadCount, setNotifyBadgeReadCount, 
            NotificationID, setNotificationID ,
            NotifyAssignEmpID, setNotifyAssignEmpID,
            NotifyAssignTaskNM, setNotifyAssignTaskNM,
            NotifyEMPname, setNotifyEMPname,
            DB_ProjectMGR_OpenTasks, setDB_ProjectMGR_OpenTasks,
            NavbarProfileImage, setNavbarProfileImage,
            isCompanyRecords, setisCompanyRecords,
            NotifyAssignedToEmployeeID, setNotifyAssignedToEmployeeID,
            DefaultValueOnTimer, setDefaultValueOnTimer
            }}>
            {children}
        </AuthContext.Provider>
    )
}

export default AuthContext;