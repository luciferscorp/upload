import React, { useState, useEffect, useRef, useContext } from 'react';
import '../assets/css/EmployeeTaskPag.css';
import { BaseUrl } from '../env/baseurl';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import PauseIcon from '@mui/icons-material/Pause';
import StopIcon from '@mui/icons-material/Stop';
import ConfirmStop from './ConfirmStop';
import AuthContext from '../../context/AuthProvider';
import HelpIcon from '@mui/icons-material/Help';
import EmployeeComment from './EmployeeComment';
import CommentImage from "../assets/images/help.png";
import CommentImageActive from "../assets/images/helpEnable.png";

const decipher = (salt) => {
    const textToChars = text => text.split('').map(c => c.charCodeAt(0));
    const applySaltToChar = code => textToChars(salt).reduce((a, b) => a ^ b, code);
    return encoded => encoded.match(/.{1,2}/g)
        .map(hex => parseInt(hex, 16))
        .map(applySaltToChar)
        .map(charCode => String.fromCharCode(charCode))
        .join('');
}
const myDecipher = decipher('mySecretSalt')

function getItemFromLocal(localData) {
    let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
    return form_data;

}

const EmployeeTaskPagination = () => {

    let local_data = getItemFromLocal("user_crypt");
    const employeeData = {
        EmployeeID: local_data.EmployeeID,
        EmployeeName: local_data.EmployeeName
    }
    const [currentPage, setCurrentPage] = useState(1);

    const [records, setrecords] = useState([]);
    const [totalPage, settotalPage] = useState();
    const [numbers, setnumbers] = useState([]);
    const [data, setdata] = useState([]);

    const recordPerPage = 5;
    const lastIndex = currentPage * recordPerPage;
    const firstIndex = lastIndex - recordPerPage;
    const [GETtaskID, setGETtaskID] = useState([])

    const [rowExpanded, setRowExpanded] = useState({});
    const [rowExpandedStop, setRowExpandedStop] = useState({});
    const [ActiveHelp, setActiveHelp] = useState(true);
    const [startedPrompt, setstartedPrompt] = useState(' ');
    const [disabledButton, setdisabledButton] = useState(true);
    const [activeEdit, setactiveEdit] = useState(false);
    const [tobeStopped, settobeStopped] = useState(null);
    const [tobeStoppedStatus, settobeStoppedStatus] = useState(null);
    const [isActive, setisActive] = useState(false);
    const [ReadData, setReadData] = useState([]);
    const [dataIn, setdataIn] = useState(undefined);
    const [newpage, setnewpage] = useState(0);

    const { NotifyBadgeReadCount, setNotifyBadgeReadCount,
        NotificationID, setNotificationID,
        NotifyAssignEmpID, setNotifyAssignEmpID,
        NotifyAssignTaskNM, setNotifyAssignTaskNM,
        NotifyEMPname, setNotifyEMPname,
        DB_ProjectMGR_OpenTasks, setDB_ProjectMGR_OpenTasks,
        NotifyAssignedToEmployeeID, setNotifyAssignedToEmployeeID } = useContext(AuthContext);

    const highlightRow = useRef("emp-task-tablerow")
    const startTimeRef = useRef(null);
    const endTimeRef = useRef(new Date());
    const diffTimeRef = useRef(null);
    setNotificationID(employeeData.EmployeeID);
    setNotifyBadgeReadCount(ReadData.reduce((sum, value) => sum + (value === 0), 0));

    function getCurrentTime() {
        var today = new Date();
        var h = today.getHours();
        var m = today.getMinutes();
        var s = today.getSeconds();
        return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
    }

    const [endTime, setendTime] = useState("00:00:00");
    function timeDifference(startTime, endTime) {
        const start = startTime.split(':').map(Number);
        const end = endTime.split(':').map(Number);
        let hoursDiff = end[0] - start[0];
        let minutesDiff = end[1] - start[1];
        let secondsDiff = end[2] - start[2];

        if (secondsDiff < 0) {
            secondsDiff += 60;
            minutesDiff--;
        }
        if (minutesDiff < 0) {
            minutesDiff += 60;
            hoursDiff--;
        }
        return [
            hoursDiff.toString().padStart(2, '0'),
            minutesDiff.toString().padStart(2, '0'),
            secondsDiff.toString().padStart(2, '0')
        ].join(':');
    }
    function timeToSeconds(time) {
        const [hours, minutes, seconds] = time.split(':').map(Number);
        return hours * 3600 + minutes * 60 + seconds;
    }
    function secondsToTime(totalSeconds) {
        const hours = Math.floor(totalSeconds / 3600);
        totalSeconds %= 3600;
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;

        return [hours, minutes, seconds]
            .map(val => val.toString().padStart(2, '0'))
            .join(':');
    }
    function addTimes(time1, time2) {
        const time1InSeconds = timeToSeconds(time1);
        const time2InSeconds = timeToSeconds(time2);
        const sumInSeconds = time1InSeconds + time2InSeconds;

        return secondsToTime(sumInSeconds);
    }
    function compareTimes(time1, time2) {
        const timeToSeconds = time => time.split(':').map(Number).reduce((acc, val, index) => acc + val * Math.pow(60, 2 - index), 0);

        const seconds1 = timeToSeconds(time1);
        const seconds2 = timeToSeconds(time2);

        if (seconds1 > seconds2) {
            return 2;
        } else if (seconds1 < seconds2) {
            return 4;
        } else {
            return 2;
        }
    }
    function prePage() {
        if (currentPage !== 1) {
            setCurrentPage(currentPage - 1);
            setnewpage(newpage - recordPerPage);
        }
    }
    function changePage(newPage) {
        if (newPage !== currentPage) {
            setCurrentPage(newPage);
            setnewpage(0);
            if (newPage > numbers[0]) {
                setnewpage(newpage + recordPerPage);
            }
            if (newPage < numbers[0]) {
                setnewpage(newpage - recordPerPage);
            }
        }
    }
    function nextPage() {
        if (currentPage !== totalPage) {
            setCurrentPage(currentPage + 1);
            setnewpage(newpage + recordPerPage);
        }
    }
    const FetchNotifyReadDATA = async () => {
        try {
            const NotifyReadDATA = { UserID: NotificationID };
            const response = await fetch("/fetchNotifyReadDATA", {
                method: "post",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(NotifyReadDATA),
            });
            const { data } = await response.json();
            setReadData(data === undefined ? [] : data.map((items) => (items.IsRead)));

        } catch (error) {
            console.error("error", error);
        }
    };
    //api get function
    async function fetchData() {
        try {
            const response = await fetch(BaseUrl + "api/getSignedEmployeetasks", {
                method: "POST",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(employeeData)
            });

            const { data, status } = await response.json();
            setdata(data);
            setRowExpandedStop(Object.fromEntries(data.map((i => [i.TaskID, i.TaskStatusID == 3 || i.TaskStatusID == 5 ? true : false]))))
            setrecords(data.slice(firstIndex, lastIndex));
            settotalPage(Math.ceil(data.length / recordPerPage));
        }
        catch (error) { console.error("error", error); }
    }
    useEffect(() => {
        FetchNotifyReadDATA();
        fetchData();
        setnumbers(Array.from({ length: totalPage }, (_, index) => index + 1));
        setRowExpanded(Object.fromEntries(data.map(i => [i.TaskID, i.isPlay == 1 ? true : false])))
    }, [currentPage, totalPage]
    )
    async function updateTaskStartTime(starttime, taskid) {
        try {
            const TaskStartTimeData = { StartTime: starttime, TaskID: taskid }
            const response = await fetch(BaseUrl + "updateTaskStartTime", {
                method: "put",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(TaskStartTimeData),
            });
        }
        catch (error) { console.error("Error", error); }
    }
    async function updateTaskEndTime(endtime, diffTime, taskid) {
        try {
            const TaskEndTimeData = { EndTime: endtime, DiffTime: diffTime, TaskID: taskid }
            const response = await fetch(BaseUrl + "updateTaskEndTime", {
                method: "put",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(TaskEndTimeData),
            });
        }
        catch (error) { console.error("Error", error); }
    }
    async function updateTaskStatus(status, taskid) {
        try {
            const TaskStatus = { TaskStatusID: status, TaskID: taskid }
            const response = await fetch(BaseUrl + "updateTaskStatus", {
                method: "put",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(TaskStatus),
            });
        }
        catch (error) { console.error("Error", error); }
    }

    async function updateTaskisPlay(status, taskid) {
        try {
            const TaskisPlay = { isPlay: status, TaskID: taskid }
            const response = await fetch(BaseUrl + "api/tasks/updateTaskisPlay", {
                method: "put",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(TaskisPlay),
            });
        }
        catch (error) { console.error("Error", error); }
    }

    function handleclick() {
        setisActive(true)
    }
    function handleclick_no() {
        setisActive(false)
    }
    function handleclick_yes() {
        updateTaskisPlay(0, GETtaskID)
        updateTaskStatus(tobeStoppedStatus, tobeStopped)
        setRowExpandedStop({ ...rowExpandedStop, [tobeStopped]: true });
        setRowExpanded({ ...rowExpanded, [GETtaskID]: false });
        setdisabledButton(true)
        setisActive(false)
        fetchData()
    }
    function handleclick_submitComment() {
        setactiveEdit(false)
    }
    function handleclick_close() {
        setactiveEdit(false)
    }
    useEffect(() => {
        setInterval(() => {
            fetchData()
        }, 1000);
    }, []);

    return (
        <>
            {data === undefined || data.length == 0 ? <div className="emp-task-bodycontainer"><div className="emp-task-tablecontainer"><h2>No Task have been created yet</h2></div></div> :
                <div className="emp-task-bodycontainer">
                    <div className='emp-task-tablecontainer'>
                        <table className="emp-task-tablecontent">
                            <thead>
                                <th className='emp-task-tablehead'>S.No.</th>
                                <th className='emp-task-tablehead'>Project Name</th>
                                <th className='emp-task-tablehead'>Team Leader Name</th>
                                <th className='emp-task-tablehead'>Task Name</th>
                                <th className='emp-task-tablehead'>Description</th>
                                <th className='emp-task-tablehead'>Duration</th>
                                <th className='emp-task-tablehead'>Work Hours</th>
                                <th className='emp-task-tablehead'>Status</th>
                                <th className='emp-task-tablehead'>Action</th>
                            </thead>
                            <tbody className='emp-task-tablebody'>
                                {records.map((ArrayData, i) => (

                                    <tr className={'emp-task-tablerow ' + highlightRow.current} key={i}>
                                        <td className='emp-task-tabledata'>{i + 1 + newpage}</td>
                                        <td className='emp-task-tabledata'>{ArrayData.ProjectName}</td>
                                        <td className='emp-task-tabledata'>{ArrayData.EmployeeName}</td>
                                        <td className='emp-task-tabledata'>{ArrayData.TaskName}</td>
                                        <td className='emp-task-description'>{ArrayData.TaskDescription}</td>

                                        <td className='emp-task-tabledata'>{ArrayData.Duration}</td>
                                        <td className='emp-task-tabledata emp-task-tabledata-workhours'>{ArrayData.DiffTime !== null ? ArrayData.DiffTime :
                                            startedPrompt === " " ? "Not Started" : ArrayData.TaskID === GETtaskID ? "Started" : "Not Started"} </td>
                                        <td className='emp-task-tabledata emp-task-tabledata-status'>
                                            {ArrayData.TaskStatusID === 1 ? <span className='emp-task-Admin-Report-Newtask'>New Task</span> :
                                                ArrayData.TaskStatusID === 2 ? <div className='emp-task-Admin-Report-pending-div'> <span className='emp-task-Admin-Report-OnProgress'>On Progress</span> </div> :
                                                    ArrayData.TaskStatusID === 4 ? <span className='emp-task-Admin-Report-Delayed'>Delayed</span> :
                                                        ArrayData.TaskStatusID === 3 ? <span className='emp-task-Admin-Report-Completed'>Completed</span> :
                                                            ArrayData.TaskStatusID === 5 ? <span className='emp-task-Admin-Report-DelayedCompleted'>Completed</span> :
                                                                "Something wrong"}
                                        </td>

                                        <td className='emp-task-tabledata  emp-task-tabledata-action'>

                                            {!rowExpanded[ArrayData.TaskID] && (

                                                <PlayArrowIcon
                                                    onClick={() => {
                                                        fetchData()

                                                        const play = () => {
                                                            !rowExpandedStop[ArrayData.TaskID] &&   setRowExpanded({ ...rowExpanded, [ArrayData.TaskID]: true });
                                                            !rowExpandedStop[ArrayData.TaskID] && (highlightRow.current = "emp-task-tablerow-indiv" + (i + 1));
                                                            !rowExpandedStop[ArrayData.TaskID] && setstartedPrompt(false)
                                                            setGETtaskID(ArrayData.TaskID);
                                                            startTimeRef.current = getCurrentTime();
                                                            !rowExpandedStop[ArrayData.TaskID] && updateTaskStartTime(getCurrentTime(), ArrayData.TaskID)
                                                            !rowExpandedStop[ArrayData.TaskID] && updateTaskStatus(compareTimes(ArrayData.Duration, ArrayData.DiffTime === null ? "00:00:00" : ArrayData.DiffTime), ArrayData.TaskID)
                                                            !rowExpandedStop[ArrayData.TaskID] && updateTaskisPlay(1, ArrayData.TaskID)

                                                        }
                                                        setDB_ProjectMGR_OpenTasks("Play");
                                                        disabledButton && play()
                                                        setdisabledButton(false)
                                                        
                                                    }
                                                    }

                                                    sx={[rowExpandedStop[ArrayData.TaskID] && { color: "gray", fontSize: "30px" }, !rowExpandedStop[ArrayData.TaskID] && { cursor: "pointer", color: "green", fontSize: "30px" }]}
                                                />
                                            )}
                                            {rowExpanded[ArrayData.TaskID] && (
                                                <PauseIcon
                                                    onClick={() => {
                                                        fetchData();
                                                        updateTaskisPlay(0, ArrayData.TaskID)
                                                        setRowExpanded({ ...rowExpanded, [ArrayData.TaskID]: false });
                                                        setGETtaskID(ArrayData.TaskID);
                                                        highlightRow.current = "emp-task-tablerow"
                                                        endTimeRef.current = getCurrentTime();
                                                        updateTaskEndTime(getCurrentTime(),addTimes(timeDifference(ArrayData.StartTime,getCurrentTime() ),ArrayData.DiffTime === null ? "00:00:00" : ArrayData.DiffTime) , ArrayData.TaskID)
                                                        updateTaskStatus(compareTimes(ArrayData.Duration, ArrayData.DiffTime === null ? "00:00:00" : ArrayData.DiffTime), ArrayData.TaskID);
                                                        setdisabledButton(true)
                                                    }
                                                    }

                                                    sx={{ color: "blue", fontSize: "30px", cursor: "pointer" }}
                                                />
                                            )}
                                            {!rowExpandedStop[ArrayData.TaskID] && (

                                                <StopIcon

                                                    onClick={() => {
                                                       
                                                        try {
                                                            endTimeRef.current = getCurrentTime();
                                                            diffTimeRef.current = timeDifference(startTimeRef.current, endTimeRef.current);
                                                            setendTime(diffTimeRef.current);
                                                            setendTime(() => addTimes(endTime, diffTimeRef.current));
                                                            updateTaskEndTime(getCurrentTime(), addTimes(endTime, addTimes(diffTimeRef.current, ArrayData.DiffTime === null ? "00:00:00" : ArrayData.DiffTime)), ArrayData.TaskID);

                                                        } catch {

                                                        }
                                                        setNotifyAssignEmpID(ArrayData.CreatedBy);
                                                        setNotifyAssignedToEmployeeID(ArrayData.AssignedToEmployeeID);
                                                        setNotifyAssignTaskNM(ArrayData.TaskName);
                                                        setNotifyEMPname(employeeData.EmployeeName)
                                                        handleclick();
                                                        settobeStopped(ArrayData.TaskID);
                                                        try {

                                                            settobeStoppedStatus(compareTimes(ArrayData.Duration, ArrayData.DiffTime === null ? "00:00:00" : ArrayData.DiffTime) === 2 ? 3 : 5)
                                                        } catch (error) {
                                                            console.error("Prompt error", error);
                                                        }
                                                        fetchData();
                                                    }
                                                    }
                                                    sx={{ cursor: "pointer", color: "#e94840", fontSize: "30px" }}
                                                />
                                            )}
                                            {rowExpandedStop[ArrayData.TaskID] && (
                                                <StopIcon
                                                    sx={{ color: "gray", fontSize: "30px" }}
                                                />
                                            )}
                                            {!rowExpandedStop[ArrayData.TaskID] && (
                                                <img className={`${ArrayData.TaskStatusID === 2 ? 'employee-comment-image-Active' : 'employee-comment-image'}`} src={`${ArrayData.TaskStatusID === 2 ? CommentImageActive : CommentImage}`}
                                                    onClick={() => {
                                                        setdataIn([
                                                            {
                                                                AssignedBy: ArrayData.CreatedBy,
                                                                UserID: employeeData.EmployeeID,
                                                                TaskName: ArrayData.TaskName,
                                                                EmployeeName: employeeData.EmployeeName
                                                            }
                                                        ]
                                                        )
                                                        { ArrayData.TaskStatusID === 2 ? setactiveEdit(true) : setactiveEdit(false) }


                                                    }} />
                                            )}
                                            {rowExpandedStop[ArrayData.TaskID] && (
                                                <img className='employee-comment-image' src={CommentImage}
                                                    onClick={() => {
                                                        setdataIn([
                                                            {
                                                                AssignedBy: ArrayData.CreatedBy,
                                                                UserID: employeeData.EmployeeID,
                                                                TaskName: ArrayData.TaskName,
                                                                EmployeeName: employeeData.EmployeeName
                                                            }
                                                        ]
                                                        )
                                                        setactiveEdit(false);
                                                    }} />
                                            )}
                                         


                                        </td>

                                    </tr>

                                ))}   {activeEdit && <EmployeeComment dataIn={dataIn} clickClose={() => handleclick_close()} clickSubmit={() => handleclick_submitComment()}/>}
                            </tbody>
                        </table>
                    </div>
                </div>}

            {data === undefined || data.length == 0 ? "" :
                <div>
                    {isActive && <ConfirmStop clickNo={() => handleclick_no()} clickYes={() => handleclick_yes()} />}
                    <div className='emp-task-navbar'>
                        <ul className='emp-task-pagination'>
                            <li className='emp-task-page-item'>
                                <a href='#' className='emp-task-page-link' onClick={prePage}>Prev</a>
                            </li>
                            {
                                numbers.map((n, i) => (
                                    <li className={`emp-task-page-item ${currentPage === n ? 'active' : ''}`} key={i}>
                                        <a href='#' className='emp-task-page-link' onClick={() => changePage(n)}>{n}</a>
                                    </li>
                                ))
                            }
                            <li className='emp-task-page-item'>
                                <a href='#' className='emp-task-page-link' onClick={nextPage}>Next</a>
                            </li>
                        </ul>
                    </div>
                </div>
            }

        </>
    )
}

export default EmployeeTaskPagination;