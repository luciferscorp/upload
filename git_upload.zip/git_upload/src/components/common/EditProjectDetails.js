import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../assets/css/AddProjects.css";
import "../assets/css/EditCompanyDetails.css";
import MultiselectDropdown from "multiselect-react-dropdown";

import Input from "./Input.js";
import Button from "./Button.js";
import { BaseUrl } from "../env/baseurl";
import DropDown from "./DropDown";


const currentDate = new Date();
const year = currentDate.getFullYear();
const month = String(currentDate.getMonth() + 1).padStart(2, '0');
const day = String(currentDate.getDate()).padStart(2, '0');
const hours = String(currentDate.getHours()).padStart(2, '0');
const minutes = String(currentDate.getMinutes()).padStart(2, '0');
const seconds = String(currentDate.getSeconds()).padStart(2, '0');

const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

function EditProjectDetails(props) {

  const [Name, setName] = useState(undefined);
  const [Description, setDescription] = useState();
  const [Status, setStatus] = useState(props.dataIn[0].isActive);

  useEffect(() => {
    setName(props.dataIn[0].ProjectName)
    setDescription(props.dataIn[0].ProjectDescription)
  }, []);

 

  let dataOut = {

    ProjectID: props.dataIn[0].ProjectID,
    ProjectName: Name,
    Description: Description,
    UpdateOn: setFormatDateTime,
  }

  const ProjectValidation = (e) => {
    e.preventDefault();

   
    //api put function 
    //api put function 
    async function updateProjectFunction() {
      try {
        const updateProjectData = dataOut;
        const response = await fetch(BaseUrl + "updateProjectData", {
          method: "put",
          mode: "cors",
          cache: "no-cache",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
          },
          redirect: "follow",
          referrerPolicy: "no-referrer",
          body: JSON.stringify(updateProjectData),
        })
        const data = await response.json();

      }
      catch (error) { console.error("Error", error); }
    }
    updateProjectFunction()
    props.callback(new Date())
  
    props.clickDone();
    // props.clickClose();
  }



  return (
    <div className="edit-model-blur">
      <div className="project-container ">
        <div>
          <h3 className="project-reg-title">Edit Project</h3>
          <buttom
            className="project-popup-close-button"
            onClick={() => props.clickClose()}
          >
            &times;
          </buttom>
        </div>

        <Input
          type="text"
          id="project_name"
          value={Name}
          maxLength="30"
          classfield="project-inputField"
          // defaultValue={props.dataIn.content.Name}
          onChange={(e) => setName(e.target.value)}
        />

        <textarea
          rows="6"
          placeholder="Describe the project here..."
          maxLength={150}
          form="usrform"
          value={Description}
          className="project-description"
          onChange={(e) => setDescription(e.target.value)}
        ></textarea>


        <div>
          <Button
            type="button"
            Title="Done"
            classfield={"blue-submit-button"}
            onClick={ProjectValidation}
          />
        </div>
      </div>

    </div>
  );
}

export default EditProjectDetails;
