import { React, useState, useEffect, useContext, useRef } from "react";
import { useNavigate } from "react-router-dom";
import "../assets/css/Navbar.css";
import { IoIosNotifications } from "react-icons/io";
import { IconContext } from "react-icons";
import profile_image from "../assets/images/blank-profile-picture-30x30.webp";
import NotificationsIcon from "@mui/icons-material/Notifications";
import Badge from "@mui/material/Badge";
import AuthContext from "../../context/AuthProvider.js";
import NotificationWindow from "./NotificationWindow";

const Navbar = (props) => {
  const [roleName, setRoleName] = useState("");
  const [empName, setEmpName] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [incrementCount, setIncrementCount] = useState(0);
  const [counter, setcounter] = useState(1);
  // Assuming the current URL is "http://localhost:3000/employee"

  const pathName = window.location.pathname; // This will give you '/employee'
  const segment = pathName.split("/")[1]; // This splits the pathname on '/' and gets the second element

 

  const navigate = useNavigate();
  const { NotifyBadgeReadCount, setNotifyBadgeReadCount, NavbarProfileImage } =
    useContext(AuthContext);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const decipher = (salt) => {
    const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
    const applySaltToChar = (code) =>
      textToChars(salt).reduce((a, b) => a ^ b, code);
    return (encoded) =>
      encoded
        .match(/.{1,2}/g)
        .map((hex) => parseInt(hex, 16))
        .map(applySaltToChar)
        .map((charCode) => String.fromCharCode(charCode))
        .join("");
  };
  const myDecipher = decipher("mySecretSalt");

  function getItemFromLocal(localData) {
    let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
    return form_data;
  }

  const userData = getItemFromLocal("user_crypt") || { EmployeeName: "" };

  const { EmployeeName, Role } = userData;

  useEffect(() => {
    setEmpName(EmployeeName);

    if (Role === 1) {
      setRoleName("Admin");
    } else if (Role === 2) {
      setRoleName("Project Manager");
    } else if (Role === 3) {
      setRoleName("Project Leader");
    } else if (Role === 4) {
      setRoleName("Member");
    } else {
      //navigate('/');
    }
  }, []);
  const modalRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        setIsModalOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="navbar">
      <div className="wrap">
        <div className="titleText">
          {segment == "dashboard"
            ? "Dashboard"
            : segment == "employee"
            ? "Member Details"
            : segment == "company"
            ? "Company Details"
            : segment == "report"
            ? "Report"
            : segment == "dashboardpl"
            ? "Dashboard"
            : segment == "leaderproject"
            ? "Project Details"
            : segment == "tasks"
            ? "Tasks Details"
            : segment == "assign"
            ? "Assign Details"
            : segment == "dashboardPM"
            ? "Dashboard"
            : segment == "projects"
            ? "Project Details"
            : segment == "projectmanager"
            ? "Assign Leader"
            : segment == "dashboardEM"
            ? "Dashboard"
            : segment == "employeetasks"
            ? "Tasks Details"
            : segment  == 'profile'
            ? 'Profile'
            : null}
        </div>
      </div>

      <IconContext.Provider value={{ color: "#fff" }}>
        <ul className="navbar-items">
          {Role != 1 ? (
            <li className="notif-icon">
              {
                <Badge
                  className="Badge-notifi"
                  badgeContent={NotifyBadgeReadCount}
                  color="error"
                >
                  <NotificationsIcon
                    className={`${
                      NotifyBadgeReadCount !== 0
                        ? "nofication-bell-icon"
                        : "Badge-notifi"
                    }`}
                    sx={{ color: "#2F2F32", fontSize: "30px" }}
                    onClick={() => {
                      if (
                        roleName === "Project Manager" ||
                        roleName === "Project Leader" ||
                        roleName === "Member"
                      ) {
                        setcounter(counter + 1);
                        openModal();
                      }
                      if (counter > 1) {
                        setIsModalOpen(false);
                        setcounter(1);
                      }
                    }}
                  />
                </Badge>
              }
            </li>
          ) : null}
          <li className="emp-name">
            {empName}
            <br />
            <span className="emp-name-role">({roleName})</span>
          </li>
          <li className="profile">
            <div className="Navbar-image">
              <img
                src={
                  NavbarProfileImage == null
                    ? profile_image
                    : NavbarProfileImage
                }
                alt="profile"
                onClick={() => {
                  navigate("/profile");
                }}
              />
            </div>
          </li>
        </ul>
      </IconContext.Provider>
      {isModalOpen && (
        <div className="notifiy-popup-modal" ref={modalRef}>
          <div className="notifiy-popup-modal-content">
            <NotificationWindow
              function={() => {
                setIsModalOpen(false);
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default Navbar;
