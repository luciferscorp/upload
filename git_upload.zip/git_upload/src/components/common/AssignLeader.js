import React, { useState, useEffect } from "react";
import "../assets/css/AddCompany.css";
import { BaseUrl } from "../env/baseurl";
import Button from "./Button.js";
import DropDown from "./DropDown";
import Input from "./Input";
import ErrorIcon from '@mui/icons-material/Error';
import MultiselectDropdown from "multiselect-react-dropdown";

const decipher = (salt) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const applySaltToChar = (code) =>
    textToChars(salt).reduce((a, b) => a ^ b, code);
  return (encoded) =>
    encoded
      .match(/.{1,2}/g)
      .map((hex) => parseInt(hex, 16))
      .map(applySaltToChar)
      .map((charCode) => String.fromCharCode(charCode))
      .join("");
};
const myDecipher = decipher("mySecretSalt");

function getItemFromLocal(localData) {
  let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
  return form_data;
}

function AssignLeader(props) {
  let local_data = getItemFromLocal("user_crypt");
  const projectleaderData = {
    EmployeeID: local_data.EmployeeID,
    EmployeeName: local_data.EmployeeName,
  };
  const [allprojectleaders, setallprojectleaders] = useState([]);
  const [allprojects, setallprojects] = useState([]);
  const [ProjectID, setProjectID] = useState("");
  const [ProjectLeader, setProjectLeader] = useState("");
  const [error, setError] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [ProjectManagerID, setProjectManagerID] = useState(0);
  const [notifyContent, setnotifyContent] = useState("");
  const [EmployeeRecords, setEmployeeRecords] = useState([]);
  const [selectedEmployees, setSelectedEmployees] = useState([]);
  const [fetchTeamLeader, setfetchTeamLeader] = useState([]);
  const [teamLeaderID, setTeamLeaderID] = useState(null);

  const assignDetails = props.assign_details;

  const convertDateString = (dateString) => {
    return dateString.split("-").reverse().join("/");
  };
  const handleEmployeeSelect = (selectedList, selectedItem) => {
    setSelectedEmployees(selectedList);
  };
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, "0");
  const day = String(currentDate.getDate()).padStart(2, "0");
  const hours = String(currentDate.getHours()).padStart(2, "0");
  const minutes = String(currentDate.getMinutes()).padStart(2, "0");
  const seconds = String(currentDate.getSeconds()).padStart(2, "0");

  const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  let projectleaders = allprojectleaders.map((items) => items.EmployeeName);
  let SelectProjectLeader = projectleaders[ProjectLeader];
  let projectleadersIDs = allprojectleaders.map((items) => items.EmployeeID);

  let projects = allprojects.map((items) => items.ProjectName);
  let projectsIDs = allprojects.map((items) => items.ProjectID);
  
  useEffect(() => {
    async function fetchTeamLeaderID() {
      try {
        const tmID = await { SelectProjectLeader: projectleaders[ProjectLeader] };
        const response = await fetch(BaseUrl + "api/fetchTeamLeaderID", {
          method: "POST",
          mode: "cors",
          cache: "no-cache",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
          },
          redirect: "follow",
          referrerPolicy: "no-referrer",
          body: JSON.stringify(tmID),
        });
        const { data } = await response.json();
        setfetchTeamLeader(data);
        setTeamLeaderID(data[0].EmployeeID); 
      } catch (error) {
        console.error("error", error);
      }
    }
    fetchTeamLeaderID();
  }, [ProjectLeader]);
  
  useEffect(() => {
    if (teamLeaderID!== null) {
      async function fetchEmployeeRecords() {
        try {
          const TeamLeaderData = { TeamLeader: teamLeaderID };
          console.log(TeamLeaderData);
          const response = await fetch(BaseUrl + "api/getallemployeeDB", {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(TeamLeaderData),
          });
          const { data } = await response.json();
          let newArray = data === null || data === undefined? [] : data.map((item) => {
            return {
              label: item.EmployeeName,
              value: item.EmployeeID,
            };
          });
          setEmployeeRecords(newArray);
        } catch (error) {
          console.error("error", error);
        }
      }
      fetchEmployeeRecords();
    }
  }, [teamLeaderID]);

  useEffect(() => {
    async function fetchEmployeeData() {
      try {
        const response = await fetch(BaseUrl + "api/getavailableprojects", {
          method: "GET",
          mode: "cors",
          cache: "no-cache",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
          },
          redirect: "follow",
          referrerPolicy: "no-referrer",
        });

        const { data } = await response.json();
        setallprojects(data == null ? [] : data);
      } catch (error) {
        console.error("error", error);
      }
    }
    async function fetchProjectData() {
      try {
        const response = await fetch(
          BaseUrl + "api/getavailableprojectleaders",
          {
            method: "GET",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
          }
        );

        const { data } = await response.json();
        setallprojectleaders(data);
      } catch (error) {
        console.error("error", error);
      }
    }
    fetchEmployeeData();
    fetchProjectData();
  }, [SelectProjectLeader]);

  async function projectManagerValidation() {
    const firstDate = new Date(startDate.split("/").reverse().join("-"));
    const secondDate = new Date(endDate.split("/").reverse().join("-"));

    if (ProjectLeader === "") {
      setError("Select Project Leader");
    } else if (selectedEmployees.length == 0) {
      setError("Select Team Members");
    } else if (startDate == "") {
      setError("Pick a start date");
    } else if (endDate == "") {
      setError("Pick a end date");
    } else if (firstDate > secondDate) {
      setError("The input date is in the past");
    } else {
      setError("");


            async function UpdateProjects() {
        try {
          let assignProjectLeaders = await {
            ProjectID: assignDetails.ProjectID,
            SelectedMembers: selectedEmployees.map((item) => item.value).toString(),
            StartDate: startDate,
            EndDate: endDate,
            ProjectLeader: projectleadersIDs[ProjectLeader],
          };
          const response = await fetch(BaseUrl + "api/assignleader", {
            method: "put",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(assignProjectLeaders),
          })
          const data = await response.json();
        }
        catch (error) { console.error("Error", error); }
      }
      UpdateProjects();
      NotifyAssignProject(projectleadersIDs[ProjectLeader], assignDetails.ProjectName);
      addNotificationEmpGroup(assignDetails.ProjectName);
      props.callback(new Date());
      props.handleclick_done();
    }
  }

  useEffect(() => {
    setProjectManagerID(projectleaderData.EmployeeID);
  }, []);

  async function NotifyAssignProject(prjLeaderID, prjName) {
    try {
      const notifyAssignedProject = await { 
        UserID: prjLeaderID,
        AssinedContent: prjName,
        CurrentDateTime: setFormatDateTime,
        CreatedBy : ProjectManagerID,
      };
      const response = await fetch(BaseUrl + "notifyAssignedProject", {
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(notifyAssignedProject),
      });
      const data = await response.json();
    } catch (error) {
      console.error("error", error);
    }
  }

  async function addNotificationEmpGroup(prjName) {
    try {
      const projectData = await {
        ProjectName: prjName,
        SelectedMembers: selectedEmployees.map((item) => item.value).toString(),
        CreatedOn: setFormatDateTime,
        CreatedBy: projectleaderData.EmployeeID,
        CreatedByName: projectleaderData.EmployeeName,
      };
      const response = await fetch("/addNotificationEmpGroup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(projectData)
      });
      const { status } = await response.json();

    }
    catch (error) { console.error("error", error); }
  }


  return (
    <div className="cd-model">
      <div className="regcontainer">
        <form name="registrationForm" method="get">
          <div>
            <h3 className="reg-title"> Assign Leader</h3>
            <buttom
              className="AssignLeadPopup-close-button"
              onClick={() => props.handleclick_close()}
            >
              &times;
            </buttom>
          </div>
          <div className="assignleader-prompt">
            <p>{`Project Name - ${assignDetails.ProjectName}`}</p>
            <p>{`Company - ${assignDetails.CompanyName}`}</p>
          </div>
          <div>
            <DropDown
              id="dropdown"
              Title="Select Project Leader"
              classfield="assignlead-dropdown"
              values={projectleaders}
              onChange={(e) => setProjectLeader(e.target.value)}
            />
          </div>
          <div className="multiselect-dropdown-addproject">
            <MultiselectDropdown
              placeholder={"Select Member"}
              options={EmployeeRecords}
              onSelect={handleEmployeeSelect}
              selectedValues={selectedEmployees}
              displayValue="label"
            />
          </div>
          <div className="divison">
            <Input
              type="date"
              placeholder="Start Date"
              classfield="startdate-inputField"
              onChange={(e) => setStartDate(e.target.value)}
              required
            />
            <Input
              type="date"
              placeholder="End Date"
              classfield="enddate-inputField"
              onChange={(e) => setEndDate(e.target.value)}
              minDate={startDate}
              isDisabled={startDate != "" ? false : true}
              required
            />
          </div>
          <span className="spanEnd" id="error">
          {error!=""? <ErrorIcon sx={{ fontSize: "18px" , position: "absolute",marginLeft:"-25px" }}/> :""}{error}
          </span>
          <div className="AddCompany-Button">
            <Button
              type="button"
              Title="Submit"
              classfield={"greenSubmitButton"}
              onClick={() => {
                projectManagerValidation();
              }}
            />
          </div>
        </form>
      </div>
    </div>
  );
}

export default AssignLeader;