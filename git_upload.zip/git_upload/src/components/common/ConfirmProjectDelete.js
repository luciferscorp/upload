import React from 'react';
import "../assets/css/ConfirmDelete.css";

function ConfirmProjectDelete(props) {


    return (
        <div className='confirm-project-delete-cd-model'>
            <div className='confirm-project-delete-cd-container'>
                <p className='confirm-project-delete-cd-text'>{`Are you sure that you want to Complete this Project`}</p>
                <div className='confirm-project-delete-cd-buttons'>
                    <div className='confirm-project-delete-cd-left-button'>
                        <button className='yes-submit-button' onClick={() => props.clickYes()}> Yes</button>
                    </div>
                    <div className='confirm-project-delete-cd-right-button'>
                        <button className='confirm-project-delete-no-submit-button' onClick={() => props.clickNo()}> No</button></div>
                </div>
            </div>
        </div>
    )
}

export default ConfirmProjectDelete