import React, { useState, useEffect,useContext } from "react";
import "../assets/css/AssignPage.css";
import Input from "./Input.js";
import Button from "./Button.js";
import DropDown from "./DropDown";
import { BaseUrl } from "../env/baseurl";
import TimePickerComponent from "./TimePickerComponent";
import AuthContext from "../../context/AuthProvider";
import ErrorIcon from '@mui/icons-material/Error';

import dayjs from "dayjs";
import { Space, TimePicker, ConfigProvider } from "antd";

const decipher = (salt) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const applySaltToChar = (code) =>
    textToChars(salt).reduce((a, b) => a ^ b, code);
  return (encoded) =>
    encoded
      .match(/.{1,2}/g)
      .map((hex) => parseInt(hex, 16))
      .map(applySaltToChar)
      .map((charCode) => String.fromCharCode(charCode))
      .join("");
};
const myDecipher = decipher("mySecretSalt");

function getItemFromLocal(localData) {
  let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
  return form_data;
}

function AssignTasks(props) {
  const [taskRecords, setTaskRecords] = useState([]);
  const [EmployeeRecords, setEmployeeRecords] = useState([]);
  const [employeeID, setemployeeID] = useState("");
  const [taskID, settaskID] = useState("");
  const [duration, setduration] = useState("");
  const [RawTime, setRawTime] = useState([]);
  const [error, setError] = useState("");
  const { DefaultValueOnTimer, setDefaultValueOnTimer} = useContext(AuthContext);

  let local_data = getItemFromLocal("user_crypt");
  const projectleaderData = {
    EmployeeID: local_data.EmployeeID,
    EmployeeName: local_data.EmployeeName,
  };
  const assignDetails = props.assign_details;


  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, "0");
  const day = String(currentDate.getDate()).padStart(2, "0");
  const hours = String(currentDate.getHours()).padStart(2, "0");
  const minutes = String(currentDate.getMinutes()).padStart(2, "0");
  const seconds = String(currentDate.getSeconds()).padStart(2, "0");
  const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  let employeeIDs = EmployeeRecords.map((items) => items.EmployeeID);
  const employee = EmployeeRecords.map((items) => items.EmployeeName);

  let taskIDs = taskRecords.map((items) => items.TaskID);
  let taskNames = taskRecords.map((items) => items.TaskName);

  useEffect(() => {
    setDefaultValueOnTimer(dayjs('2022-04-17T00:00:00'));
    async function fetchTaskData() {
      try {
        const response = await fetch(BaseUrl + "api/gettasks", {
          method: "POST",
          mode: "cors",
          cache: "no-cache",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
          },
          redirect: "follow",
          referrerPolicy: "no-referrer",
          body: JSON.stringify(projectleaderData),
        });

        const { data } = await response.json();
        setTaskRecords(data || []);
      } catch (error) {
        console.error("error", error);
      }
    }

    //get the employee in particular leader

    async function fetchEmployeeData() {
      try {
        const response = await fetch(BaseUrl + "api/getallemployee", {
          method: "POST",
          mode: "cors",
          cache: "no-cache",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
          },
          redirect: "follow",
          referrerPolicy: "no-referrer",
          body: JSON.stringify(projectleaderData),
        });

        const { data } = await response.json();
        setEmployeeRecords(data || []);
      } catch (error) {
        console.error("error", error);
      }
    }


    fetchTaskData();
    fetchEmployeeData();
  }, []);

  async function NotifyAssignTask() {
    try {
      const notifyAssignedProject = {
        CreatedBy: projectleaderData.EmployeeID,
        LeaderName: projectleaderData.EmployeeName,
        TaskName: assignDetails.TaskName,
        ProjectName: assignDetails.ProjectName,
        Duration: duration,
        TaskDescription: assignDetails.TaskDescription,
        UserID: employeeIDs[employeeID],
        LoggedUserName: assignDetails.LoggedUserName,
        CreatedOn: setFormatDateTime,
      };
      const response = await fetch(BaseUrl + "notifyAssignedTask", {
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(notifyAssignedProject),
      });
      const data = await response.json();
    } catch (error) {
      console.error("error", error);
    }
  }

  const AssignValidation = (e) => {
    e.preventDefault();
    if (employeeID == "") {
      setError("Select Member");
    } else if (duration == "") {
      setError("Assign duration");
    } else {
      setError("");

      const assignData = {
        AssignedToEmployeeID: employeeIDs[employeeID],
        TaskID: assignDetails.TaskID,
        Duration: duration,
        TaskStatusID: 1,
      };

    

      async function fetchAssignTask() {
        try {
          const response = await fetch(BaseUrl + "api/assigntasks", {
            method: "PUT",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(assignData),
          });

         
        } catch (error) {
          console.error("error", error);
        }
      }

      fetchAssignTask();
      props.callback(new Date());
      props.handledone_close();
    }
    NotifyAssignTask();
  };

  return (
    <div className="cd-model">
      <div className="regcontainer">
        <form name="registrationForm" method="get">
          <div>
            <h3 className="reg-title">Assign</h3>
            <buttom
              className="CompPopup-close-button"
              onClick={() => props.handleclick_close()}
            >
              &times;
            </buttom>
          </div>
          <div>
            <p className="assign-task-prompt">{`Project Name - ${assignDetails.ProjectName}`}</p>
            <p className="assign-task-prompt">{`Task Name - ${assignDetails.TaskName}`}</p>
            <p className="assign-task-prompt">{`Task Description - ${assignDetails.TaskDescription}`}</p>
          </div>
          <div>
            <DropDown
              id="dropdown"
              classfield="assign-employee-dropdown"
              Title="Select Employee"
              values={employee}
              onChange={(e) => {
                setemployeeID(e.target.value);
              }}
            />
          </div>
          <div>
            <TimePickerComponent
            defaultValue={DefaultValueOnTimer}
              handlechange={(e) => setduration(e.toString().split(" ")[4])}
            />
          </div>
          <span className="spanEnd" id="error">
          {error!=""? <ErrorIcon sx={{ fontSize: "18px" , position: "absolute",marginLeft:"-25px" }}/> :""}{error}
          </span>
          <div className="AddCompany-Button">
            <Button
              type="button"
              Title="Submit"
              classfield={"greenSubmitButton"}
              onClick={AssignValidation}
            />
          </div>
        </form>
      </div>
    </div>
  );
}

export default AssignTasks;