import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../assets/css/AddCompany.css";

import Input from "./Input.js";
import Button from "./Button.js";
import { BaseUrl } from "../env/baseurl";
import ErrorIcon from '@mui/icons-material/Error';

const decipher = (salt) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const applySaltToChar = (code) =>
    textToChars(salt).reduce((a, b) => a ^ b, code);
  return (encoded) =>
    encoded
      .match(/.{1,2}/g)
      .map((hex) => parseInt(hex, 16))
      .map(applySaltToChar)
      .map((charCode) => String.fromCharCode(charCode))
      .join("");
};
const myDecipher = decipher("mySecretSalt");

function getItemFromLocal(localData) {
  let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
  return form_data;
}

function AddCompany(props) {
  const navigate = useNavigate();

  const [companyName, setCompanyName] = useState("");
  const [error, setError] = useState("");
  const [companyNameVerify, setCompanyNameVerify] = useState([]);
  // let currentDateRaw = new Date()
  // let currentDdate = currentDateRaw.toISOString().split('T')[0].split("-").reverse().join("/");

  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, "0");
  const day = String(currentDate.getDate()).padStart(2, "0");
  const hours = String(currentDate.getHours()).padStart(2, "0");
  const minutes = String(currentDate.getMinutes()).padStart(2, "0");
  const seconds = String(currentDate.getSeconds()).padStart(2, "0");

  const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  const [count, setcount] = useState(0);

  // let Company1 = companyNameVerify.toString().toLowerCase();
  // let Company2 =   companyName.toString().toLowerCase();
  const CompanyValidation = (e) => {
    e.preventDefault();

    if (companyName === "") {
      setError("Enter the company name");
    } else if (!isNaN(companyName)) {
      setError("Company name should not be with numbers");
    } else if (companyNameVerify.includes(companyName.toLowerCase())) {
      setError(" Name already exist ");
    } else {
      setError("");

      // const userData = getItemFromLocal("user_local") || { EmployeeID: null };

      // const {
      //   EmployeeID
      // } = userData;

      const companyData = {
        CompanyName: companyName,
        CreatedOn: setFormatDateTime,
        CreatedBy: "Admin",
      };

      async function fetchData() {
        try {
          let url = BaseUrl + "api/addcompany";
          const response = await fetch(url, {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(companyData),
          });
          const result = await response.json().then((data) => {
          
          });
        } catch (error) {
          console.error("Error", error);
        }
      }
      fetchData();

      props.callback(new Date());

      props.function();
      props.close();
    }
  };
  //api get function
  async function GetCompanyData() {
    try {
      const response = await fetch(BaseUrl + "getallcompanies", {
        method: "GET",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
      });
      const { data } = await response.json();
  
      const companydata = data.map((value) => value.CompanyName.toLowerCase());

      setCompanyNameVerify(companydata);
    } catch (error) {
      console.error("error", error);
    }
  }
  useEffect(() => {
    GetCompanyData();
  }, []);

  return (
    <div>
      <div className="regcontainer">
        <form name="registrationForm" method="get">
          <div>
            <h3 className="reg-title">Add Company</h3>
            <buttom
              className="CompPopup-close-button"
              onClick={() => props.function()}
            >
              &times;
            </buttom>
          </div>
          <div>
            <Input
              type="text"
              id="companyName"
              placeholder="Company Name"
              maxLength="20"
              classfield="inputField"
              onChange={(e) => setCompanyName(e.target.value)}
            />
          </div>
          <span className="spanEnd" id="error">
          {error!=""? <ErrorIcon sx={{ fontSize: "18px" , position: "absolute",marginLeft:"-25px" }}/> :""}{error}
          </span>
          <div className="AddCompany-Button">
            <Button
              type="button"
              Title="Submit"
              classfield={"greenSubmitButton"}
              onClick={CompanyValidation}
            />
          </div>
        </form>
      </div>
    </div>
  );
}

export default AddCompany;
