import React, { useState, useEffect } from "react";
import "../assets/css/AddProjects.css";
import "../assets/css/EditCompanyDetails.css";
import Button from "./Button.js";
import { BaseUrl } from "../env/baseurl";

function EmployeeComment(props) {

  const [Comment, setComment] = useState();
  const [NotificationData, setNotificationData] = useState([]);

  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, "0");
  const day = String(currentDate.getDate()).padStart(2, "0");
  const hours = String(currentDate.getHours()).padStart(2, "0");
  const minutes = String(currentDate.getMinutes()).padStart(2, "0");
  const seconds = String(currentDate.getSeconds()).padStart(2, "0");
  const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  
  const CommentValidation = (e) => {
    e.preventDefault();

    let dataOut = {
      UserID : props.dataIn[0].AssignedBy,
      Content  : Comment,
      Assigned : props.dataIn[0].UserID,
      CreatedOn : setFormatDateTime,
      TaskName : props.dataIn[0].TaskName,
      EmployeeName : props.dataIn[0].EmployeeName
    }
   
    async function NotifyEmployeeCommentFunc() {
      try {
        const NotifyEmployeeComment = dataOut;
        const response = await fetch(BaseUrl + "NotifyEmployeeComment", {
          method: "post",
          mode: "cors",
          cache: "no-cache",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
          },
          redirect: "follow",
          referrerPolicy: "no-referrer",
          body: JSON.stringify(NotifyEmployeeComment),
        })
        const { status } = await response.json();
      }
      catch (error) { console.error("Error", error); }
    }
    NotifyEmployeeCommentFunc();
    props.clickSubmit();
  }


  return (
    <div className="employee-comment-edit-model-blur">
      <div className="employee-comment-project-container">
        <div>
          <h3 className="employee-comment-project-reg-title">Comment</h3>
          <buttom
            className="employee-comment-project-popup-close-button"
            onClick={() => props.clickClose()}
          >
            &times;
          </buttom>
        </div>
        <textarea
          rows="6"
          placeholder="Comment..."
          maxLength={150}
          form="usrform"
          className="employee-comment-project-description"
          onChange={(e) => setComment(e.target.value)}
        ></textarea>
        <div>
          <Button
            type="button"
            Title="Submit"
            classfield={"blue-submit-button"}
            onClick={CommentValidation}
          />
        </div>
      </div>

    </div>
  );
}

export default EmployeeComment;