import React, { useState } from "react";
import "../assets/css/DownloadPDF.css";

import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import DownloadIcon from "@mui/icons-material/Download";

import loginLogo from '../assets/images/loginLogo.png'


function DownloadPDF(props) {

  var currentDate = new Date();

  var formattedDate = currentDate.toLocaleDateString('en-IN', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    second: 'numeric',
    // timeZoneName: 'short'
  }); // Example output: Thursday, 25 April, 2024, 12:45:30 PM IST

  const jsPDFDownload = () => {
    const doc = new jsPDF("l", "pt");

    // const pdf=  new jsPDF('p','pt');


    let ArrayData = props.tobedownloaded;


    if (props.role == 3) {
      //Formating the fetched data
      let formatedArrayHead = [...["S.No"], ...Object.keys(ArrayData[0])];
      let formatedArrayData = ArrayData.map((item, index) => [
        ...[index + 1],
        ...Object.values(item),
      ]);



      // //Reordering the data
      let reorderedArrayHead = [
        ...formatedArrayHead.splice(3, 4),
        formatedArrayHead[0],
      ].reverse();

     
      let reorderedArrayData = formatedArrayData.map((item) =>
        [...item.splice(3, 4), item[0]].reverse()
      );



      // From Javascript
      var finalY = doc.lastAutoTable.finalY || 10;
      doc.text("Tasks Created by the Project Leader", 14, finalY + 15);
      autoTable(doc, {
        startY: finalY + 35,
        head: [reorderedArrayHead],
        body: reorderedArrayData,
      });

      doc.save("table.pdf");
    }

    //For admin
    else if (props.role == 1) {
      //Formating the fetched data



      let formatedArrayHead = [...["S.No"], ...Object.keys(ArrayData[0])];

      // let reorderedArrayHead = [
      //   formatedArrayHead[0],
      //   "ProjectName",
      //   formatedArrayHead[12],
      //   formatedArrayHead[3],
      //   formatedArrayHead[7],
      //   "ProjectLeader",
      //   "EmployeeName",
      //   formatedArrayHead[11],
      //   "Status",
      // ];

      let reorderedArrayHead = [
        'S.No',
        'Project Name',
        'Task Name',
        'Task Description',
        'Created On',
        'Project Leader',
        'Employee Name',
        'Duration',
        'Status',
        "Time Spend"
      ]
     
      let reorderedArrayData = ArrayData.map((item, index) => [
        index + 1,
        item.ProjectIDName,
        item.TaskName,
        item.TaskDescription,
        item.CreatedOn,
        item.CreatedByName,
        item.EmployeeName == null ? "-" : item.EmployeeName,
        item.Duration == null ? "   -" : item.Duration + " Hrs",
        item.TaskStatusID == null
          ? "Pending"
          : (item.TaskStatusID == 1) | (item.TaskStatusID == 2)
            ? "On Progress"
            : (item.TaskStatusID == 3) | (item.TaskStatusID == 4)
              ? "Completed"
              : "   -",
        item.DiffTime == null ? "   -" : item.DiffTime + " Hrs",
      ]);
     
      const addFooters = doc => {
        const pageCount = doc.internal.getNumberOfPages()
        doc.setFontSize(10);
     
        for (var i = 1; i <= pageCount; i++) {
          doc.setPage(i)    
          doc.text('Page ' + String(i) + ' of ' + String(pageCount),450, 580, {
            align: 'right',
        });
        }
      }

      // From Javascript
      var finalY = doc.lastAutoTable.finalY || 10;
      doc.addImage(loginLogo, "PNG", 35, 7, 50, 40)
      doc.setFontSize(9);
      doc.text("Generated on " + formattedDate , 590, 16)
      doc.setFontSize(20);
      doc.text("Task Report", 355, finalY + 15);
      autoTable(doc, {
        startY: finalY + 35,
        head: [reorderedArrayHead],
        body: reorderedArrayData,
        columnStyles: {
          0: { cellWidth: 34 },
          1: { cellWidth: 80 }, // Adjust width of the second column
          2: { cellWidth: 90 }, // Adjust width of the third column
          // 3: { cellWidth: 180 },
          4: { cellWidth: 66 },
          5: { cellWidth: 79 },
          6: { cellWidth: 86},
          7: { cellWidth: 67 },
          8: { cellWidth: 60 },
          9: { cellWidth: 67 },

        },
        // options: options
      });
      addFooters(doc);

      doc.save("task_report.pdf");
    }
  };

  return (
    <div className="download-btn-class">
      <a className="face-button" href="#" onClick={() => jsPDFDownload()}>
        <div className="face-primary">
          <span className="icon fa fa-download"></span>
          Download
        </div>

        <div className="face-secondary">
          <span className="icon fa fa-hdd-o"></span>
          convert to PDF
        </div>
      </a>

      {/* <button className='download-button' onClick={() => jsPDFDownload()}>Download</button> */}
      {/* <DownloadIcon className='download-button' onClick={() => jsPDFDownload()}  */}
      {/* sx={{color:"green", fontSize:"37px"}}/> */}
    </div>
  );
}

export default DownloadPDF;