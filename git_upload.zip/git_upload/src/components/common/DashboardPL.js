import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import TaskPagination from "./TaskPagination";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import DownloadPDF from "./DownloadPDF";
import React, { useState, useEffect, useContext } from "react";
import AuthContext from "../../context/AuthProvider";
import { BaseUrl } from "../env/baseurl";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import "../assets/css/DashboardPL.css";
import Footer from "./footer";
import LimitedText from "./LimitedText";

const decipher = (salt) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const applySaltToChar = (code) =>
    textToChars(salt).reduce((a, b) => a ^ b, code);
  return (encoded) =>
    encoded
      .match(/.{1,2}/g)
      .map((hex) => parseInt(hex, 16))
      .map(applySaltToChar)
      .map((charCode) => String.fromCharCode(charCode))
      .join("");
};
const myDecipher = decipher("mySecretSalt");
function getItemFromLocal(localData) {
  let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
  return form_data;
}

export default function DashBoardPL() {
  let local_data = getItemFromLocal("user_crypt");
  const employeeData = {
    EmployeeID: local_data.EmployeeID,
    EmployeeName: local_data.EmployeeName,
  };
  const [ReadData, setReadData] = useState([]);
  const {
    NotifyBadgeReadCount,
    setNotifyBadgeReadCount,
    NotificationID,
    setNotificationID,
    NotifyEMPname,
    setNotifyEMPname,
  } = useContext(AuthContext);
  setNotificationID(employeeData.EmployeeID);
  setNotifyBadgeReadCount(
    ReadData.reduce((sum, value) => sum + (value === 0), 0)
  );

  const [PendingData, setPendingData] = useState([]);
  const [ProgressData, setProgressData] = useState([]);
  const [CompletedData, setCompletedData] = useState([]);
  const [taskData, settaskData] = useState([]);
  const [PendingCreatedOn, setPendingCreatedOn] = useState([]);
  const [OnProgressCreatedOn, setOnProgressCreatedOn] = useState([]);
  const [CompletedCreatedOn, setCompletedCreatedOn] = useState([]);

  const PendingFormatDate = PendingCreatedOn.map((date) => {

    if (date[2] == "/") {
      const [day, month, year] = date.split("/");
      return `${month}/${day}/${year}`;
    } else {

      const [year, month, day] = date.split(" ")[0].split("-");
      return `${month}/${day}/${year}`;
    }

  });

  const PENoptions = { year: "numeric", month: "short", day: "numeric" };
  const FormattedPendingDATE = PendingFormatDate.map((date) =>
    new Date(date).toLocaleDateString("en-IN", PENoptions)
  );

  const ProgressFormatDate = OnProgressCreatedOn.map((date) => {
    const [day, month, year] = date.split("/");
    return `${month}/${day}/${year}`;
  });
  const PROGoptions = { year: "numeric", month: "short", day: "numeric" };
  const FormattedProgressDATE = ProgressFormatDate.map((date) =>
    new Date(date).toLocaleDateString("en-IN", PROGoptions)
  );

  const CompleteFormatDate = CompletedCreatedOn.map((date) => {
    const [day, month, year] = date.split("/");
    return `${month}/${day}/${year}`;
  });
  const COMPoptions = { year: "numeric", month: "short", day: "numeric" };
  const FormattedCompleteDATE = CompleteFormatDate.map((date) =>
    new Date(date).toLocaleDateString("en-IN", COMPoptions)
  );

  async function FetchTaskDataForLeader() {
    const NotifyReadDATA = { EmployeeID: employeeData.EmployeeID };
    try {
      const response = await fetch(BaseUrl + "api/FetchTaskDataForLeader", {
        method: "post",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(NotifyReadDATA),
      });
      const { data } = await response.json();
      setPendingData(data === undefined || data === null ? [] : data);
      setPendingCreatedOn(data.map((items) => items.CreatedOn));
    } catch (error) {
      console.error("error", error);
    }
  }

  async function GetTaskRecord() {
    try {
      const response = await fetch("/api/GetTaskIDNAMES", {
        method: "GET",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
      });
      const { data } = await response.json();
      settaskData(data === undefined || data === null ? [] : data);
    } catch (error) {
      console.error("error", error);
    }
  }

  useEffect(() => {
    FetchTaskDataForLeader();
    GetTaskRecord();
  }, []);

  const FetchNotifyReadDATA = async () => {
    try {
      const NotifyReadDATA = { UserID: NotificationID };
      const response = await fetch("/fetchNotifyReadDATA", {
        method: "post",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(NotifyReadDATA),
      });
      const { data } = await response.json();
      setReadData(data === undefined ? [] : data.map((items) => items.IsRead));
    } catch (error) {
      console.error("error", error);
    }
  };
  FetchNotifyReadDATA();

  return (
    <>
      <div>
        <Navbar />
        <Sidebar />
      </div>
      {PendingData === undefined || PendingData.length == 0 ? 
      <div className="emp-bodycontainer">
        <div className='emp-tablecontainer'>
          <h2>No data have been created yet</h2>
          </div>
          </div> : 
          <div className="emp-bodycontainer">
        <div>
          <div className="DB_PL_container_wrapper">
            <h3 className="dashboard-PL-Heading">
              Welcome {employeeData.EmployeeName},
            </h3>
            <div>
              <h3 className="dashboard-PL-Task-Heading">Task Details</h3>
            </div>
            <div className="DB_PL_container_rows">
              <div className="DB_PL_container-pending">

                <div className="Leadercard-container">
                  {PendingData.map((item, index) => (
                    <div className="Leadercard">
                      <div
                        className={
                          item.TaskStatusID === 0
                            ? "Leaderheading-containerNotAssigned"
                            : item.TaskStatusID === 1
                              ? "Leaderheading-containerPending"
                              : item.TaskStatusID === 2
                                ? "Leaderheading-containerProgress"
                                : item.TaskStatusID === 3
                                  ? "Leaderheading-containerComplete"
                                  : "Leaderheading-containerDelayed"
                        }
                      >
                        <h3
                          className={
                            item.TaskStatusID === 0
                              ? "LeaderheadingNotAssigned"
                              : item.TaskStatusID === 1
                                ? "LeaderheadingPending"
                                : item.TaskStatusID === 2
                                  ? "LeaderheadingProgress"
                                  : item.TaskStatusID === 3
                                    ? "LeaderheadingComplete"
                                    : "LeaderheadingDelayed"
                          }
                        >
                          {item.TaskStatusID === 0
                            ? "Not Assigned"
                            : item.TaskStatusID === 1
                              ? "Pending"
                              : item.TaskStatusID === 2
                                ? "OnProgress"
                                : item.TaskStatusID === 3
                                  ? "Completed"
                                  : "Delayed"}
                        </h3>
                      </div>
                      <h3>{item.ProjectName}</h3>
                      <p>
                        <strong>Task Name:</strong> {item.TaskName}
                      </p>
                      <p className="dashboard-Pl-desc"> <LimitedText text={item.TaskDescription} limit={100} /></p>
                      <p>
                        <strong>Assigned To:</strong>{" "}
                        {item.AssignedToEmployeeName == null
                          ? "-"
                          : item.AssignedToEmployeeName}
                      </p>
                      <div
                        className="dashboard-PL-task-deadline"
                        style={{
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                          backgroundColor: "#FFEFF1",
                        }}
                      >
                        <AccessTimeIcon
                          sx={{
                            fontSize: "25px",
                            color: "#FC6075",

                          }}
                        />
                        <p
                          style={{
                            margin: "0",
                            marginLeft: "5px",
                            color: "#FC6075",
                            backgroundColor: "#FFEFF1",
                          }}
                        >
                          DeadLine:{FormattedPendingDATE[index]}
                        </p>
                      </div>

                      <p>
                        <strong>Project Leader: </strong>
                        {item.ProjectLeaderName}
                      </p>
                    </div>
                  ))}
                </div>

              </div>

            </div>
          </div>
        </div>
      </div>}
      <div className="report-footer">
        <Footer />
      </div>
    </>
  );
}