import React, { useState, useEffect } from 'react';
import '../assets/css/ProjectsPagination.css';
import { BaseUrl } from '../env/baseurl';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import DoneIcon from '@mui/icons-material/Done';
import TextField from '@mui/material/TextField';
import Button from "./Button.js";
import Input from "./Input.js";
import ConfirmDelete from './ConfirmDelete';
import { Icon, IconButton } from '@mui/material';
import EditStatusPopup from './EditStatusPopup';
import EditProjectDetails from './EditProjectDetails';




const currentDate = new Date();
const year = currentDate.getFullYear();
const month = String(currentDate.getMonth() + 1).padStart(2, '0');
const day = String(currentDate.getDate()).padStart(2, '0');
const hours = String(currentDate.getHours()).padStart(2, '0');
const minutes = String(currentDate.getMinutes()).padStart(2, '0');
const seconds = String(currentDate.getSeconds()).padStart(2, '0');

const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;


const ProjectPagination = (props) => {


    const [currentPage, setCurrentPage] = useState(1);
    const [data, setdata] = useState([]);
    const [records, setrecords] = useState([]);
    const [totalPage, settotalPage] = useState();
    const [numbers, setnumbers] = useState([]);

    const recordPerPage = 5;
    const lastIndex = currentPage * recordPerPage;
    const firstIndex = lastIndex - recordPerPage;
    const [activeProjectId, setactiveProjectId] = useState(null);
    const [activeProjectName, setactiveProjectName] = useState("");
    const [activeProjectDescription, setactiveProjectDescription] = useState("");
    const [hide, setHide] = useState(false);
    const [hideEdit, setHideEdit] = useState(new Set());
    /// set() consist of add , delete, has 
    const [counter, setcounter] = useState(0);
    const [isActive, setisActive] = useState(false);
    const [tobeDeleted, settobeDeleted] = useState("");
    const [ProjectIdCompare, setProjectIdCompare] = useState(0);
    const [WhileClick, setWhileClick] = useState(false)
    const [newpage, setnewpage] = useState(0);

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isSaved, setisSaved] = useState(false)
    const [payload, setpayload] = useState('initialState');
    const [count, setcount] = useState(0);
    const [incrementCount, setIncrementCount] = useState(0);


    const [dataIn, setdataIn] = useState(undefined);
    const [activeEdit, setactiveEdit] = useState(false);
    const [editedDetails, setEditedDetails] = useState();
    const [fetchStatus, setfetchStatus] = useState("");

    const callback = payload => {
       
        setfetchStatus(payload)
    }
    const handleIncrementCount = () => {
        if (count > 0) {
         
          setcount(0);
        }
      
        setIncrementCount(incrementCount + 1);
    
      };


    function prePage() {
        if (currentPage !== 1) {
            setCurrentPage(currentPage - 1);
            setnewpage(newpage - recordPerPage);
        }
    }
    function changePage(newPage) {
        if (newPage !== currentPage) {
            setCurrentPage(newPage);
            setnewpage(0);
            if (newPage > numbers[0]) {
                setnewpage(newpage + recordPerPage);
            }
            if (newPage < numbers[0]) {
                setnewpage(newpage - recordPerPage);
            }
        }
    }
    function nextPage() {
        if (currentPage !== totalPage) {
            setCurrentPage(currentPage + 1);
            setnewpage(newpage + recordPerPage);
        }
    }

    //api get function 
    async function fetchData() {
        try {
            let url = BaseUrl + "api/getallprojects"
            const response = await fetch(url, {
                method: "GET",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
            });
            const { data } = await response.json();
            setdata(data)
            setrecords(data.slice(firstIndex, lastIndex))
            settotalPage(Math.ceil(data.length / recordPerPage))
        }
        catch (error) { console.error("error", error); }
    }


    useEffect(() => {
        fetchData();
        setnumbers(Array.from({ length: totalPage }, (_, index) => index + 1));
    }, [currentPage, totalPage, fetchStatus]);

    useEffect(() => {
        
        setTimeout(() => {
            fetchData();
        }, 400);
    }, [props.doFetch, fetchStatus]);

    //api put function 
    async function updateProjectFunction(projectUpdateParam) {
        try {
            const updateProjectData =
            {
                ProjectName: activeProjectName,
                Description: activeProjectDescription,
                ProjectID: projectUpdateParam,
                UpdateOn: setFormatDateTime,
            }
            const response = await fetch(BaseUrl + "updateProjectData", {
                method: "put",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(updateProjectData),
            })
            const data = await response.json();

        }
        catch (error) { console.error("Error", error); }
    }

    //api delete function 
    async function deleteProjectRecord(projectDeleteParam) {
        try {
            const deleteProjectData = { id: projectDeleteParam };
            const response = await fetch(BaseUrl + 'deleteProjectData', {
                method: "put",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(deleteProjectData),
            });
            const data = await response.json();
     

        } catch (error) {
            console.error("error", error);
        }
    }


    function handleclick() {
        setisActive(true)
    }

    function handleclick_no() {
        setisActive(false)
    }

    function handleclick_yes() {
        deleteProjectRecord(tobeDeleted)
        fetchData()
        setisActive(false)
    }

    function handleclick_doneEdit() {
        setactiveProjectId(!activeProjectId);
        // setactiveProjectName(ArrayData.isActive);
        setProjectIdCompare(!ProjectIdCompare)
        setWhileClick(!WhileClick)
        setHide(!hide)
        setcounter(counter + 1);
        setactiveEdit(false)
        setisSaved(true);
        handleIncrementCount();

    }

    function handleclick_close() {
        setactiveProjectId(!activeProjectId);
        // setactiveProjectName(ArrayData.isActive);
        setProjectIdCompare(!ProjectIdCompare)
        setWhileClick(!WhileClick)
        setHide(!hide)
        setcounter(counter + 1);
        setactiveEdit(false)
    }


    return (
        <>
        <div>
                {isSaved && (<EditStatusPopup message={"successfully Edited!"} timeout={2000}  handleIncrementCount={handleIncrementCount}  />)}
                </div>
            {data === undefined || data.length == 0 ? <div className="prj-bodycontainer"><div className='prj-tablecontainer'><h2>No project have been created yet</h2></div></div> : <div className="prj-bodycontainer">
                <div className='prj-tablecontainer'>
                    <table className="prj-tablecontent">
                        {/* <h4 className='ProjectPagination-heading' >Project Details</h4> */}
                        <thead>
                            <th className='prj-tablehead'>S.No</th>
                            <th className='prj-tablehead'>Project Name</th>
                            <th className='prj-tablehead '>Description</th>
                            <th className='prj-tablehead'>Company Name</th>

                            <th className='prj-tablehead'>Action</th>
                        </thead>
                        <tbody className='prj-tablebody'>
                            {records.map((ArrayData, i) => (
                                <tr className='prj-tablerow' key={i}>
                                    <td className='prj-tabledata'>{i + 1 + newpage}</td>
                                    {/* project name  */}
                                    <td className='prj-tabledata'>
                                        {ArrayData.ProjectName}
                                    </td>

                                    {/* project description */}
                                    <td className=' prj-description'>
                                        {ArrayData.Description}
                                    </td>
                                    <td className='prj-tabledata'>{ArrayData.CompanyName}</td>

                                    {/* action field  */}
                                    <td className='cmp-tabledata'>
                                        {ArrayData.ProjectID !== activeProjectId &&
                                            <IconButton disabled={ProjectIdCompare ? true : false} sx={{ color: "#54B4D3", margin: "0 -15px 0px 0" }}>
                                                <EditIcon sx={{ cursor: "pointer" }}
                                                    onClick={() => {
                                                        setProjectIdCompare(ArrayData.ProjectID);
                                                        // updateProjectFunction(ArrayData.ProjectID);
                                                        setactiveProjectId(ArrayData.ProjectID);
                                                        setactiveProjectName(ArrayData.ProjectName);
                                                        setWhileClick(true);
                                                        setactiveProjectDescription(ArrayData.Description);
                                                        setHide(!hide);
                                                        setHideEdit(hideEdit.add(ArrayData.ProjectID));
                                                        setactiveProjectName(ArrayData.isActive)

                                                        setdataIn([
                                                            {
                                                                ProjectID: ArrayData.ProjectID,
                                                                ProjectName: ArrayData.ProjectName,
                                                                ProjectDescription: ArrayData.Description
                                                            }
                                                        ]
                                                        )
                                                        setactiveEdit(true);
                                                        setcount(count + 1);
                                                        setisSaved(false);
                                                    }} />
                                            </IconButton>}

                                        {hide && ArrayData.ProjectID === activeProjectId &&
                                            (<DoneIcon sx={{ cursor: "pointer", marginLeft: "10px", marginRight: "-6px", color: "#5cb85c" }}
                                                onClick={() => {
                                                    // updateProjectFunction(ArrayData.ProjectID);
                                                    setactiveProjectId(!ArrayData.ProjectID);
                                                    setactiveProjectName(ArrayData.isActive);
                                                    setProjectIdCompare(!ProjectIdCompare)
                                                    setWhileClick(!WhileClick)
                                                    setHide(!hide)
                                                    setcounter(counter + 1);
                                                    fetchData()
                                                    setactiveEdit(false)
                                                }} />)}

                                        {ArrayData.ProjectID &&
                                            <IconButton disabled={WhileClick} sx={{ color: "#DC3545" }}>
                                                <DeleteIcon sx={{ cursor: "pointer", marginLeft: "5px" }} onClick={() => {

                                                    // deleteProjectRecord(ArrayData.ProjectID)
                                                    handleclick();
                                                    settobeDeleted(ArrayData.ProjectID)
                                                }} />
                                            </IconButton>}

                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                {isActive && <ConfirmDelete content={"project"} clickNo={() => handleclick_no()} clickYes={() => handleclick_yes()} />}
                {activeEdit && <EditProjectDetails dataIn={dataIn} clickClose={() => handleclick_close()} clickDone={() => handleclick_doneEdit()}
                    callback={callback}
                />}
            </div>}

            {data === undefined || data.length == 0 ? "" : <div className='prj-navbar'>
                <ul className='prj-pagination'>
                    <li className='prj-page-item'>
                        <a href='#' className='prj-page-link' onClick={prePage}>Prev</a>
                    </li>
                    {
                        numbers.map((n, i) => (
                            <li className={`prj-page-item ${currentPage === n ? 'active' : ''}`} key={i}>
                                <a href='#' className='prj-page-link' onClick={() => changePage(n)}>{n}</a>
                            </li>
                        ))
                    }
                    <li className='prj-page-item'>
                        <a href='#' className='prj-page-link' onClick={nextPage}>Next</a>
                    </li>
                </ul>
            </div>}

        </>
    )



}

export default ProjectPagination;