
import React, { useState } from 'react';
import '../assets/css/CompPopup.css'
import StatusPopup from './../common/StatusPopup';
import AssignTasks from './AssignTasks';

const AssignPagePopup = (props) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSaved, setisSaved] = useState(false);
  const [count, setcount] = useState(0);
  const [incrementCount, setIncrementCount] = useState(0);
  const [payload, setpayload] = useState('initialState');

  const openModal = () => {
    setIsModalOpen(true);
  };


  const callback = payload => {
    setpayload(payload)
    props.callback(payload)
  }


  const handleIncrementCount = () => {
    if (count > 0) {
    
      setcount(0);
    }

    setIncrementCount(incrementCount + 1);

  };

  return (
    <div className="popup-container">
      <button className="CompPopup-openBtn" onClick={() => { openModal(); setcount(count + 1); setisSaved(false); }}>{props.title}</button>

      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">

            <AssignTasks function={() => { setIsModalOpen(false) }}
              close={() => { setisSaved(true); handleIncrementCount(); }} 
            callback={callback}
            />
          </div>
        </div>
      )}
      {isSaved && (<StatusPopup message={"Successfully Added!"} timeout={2000} handleIncrementCount={handleIncrementCount} />)}
    </div>
  );
};

export default AssignPagePopup;