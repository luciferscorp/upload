import React, { useState, useEffect } from 'react'
import '../assets/css/DashboardADMIN.css'
import { BaseUrl } from '../env/baseurl';

import employeeicon from "../assets/images/Employee.png";
import taskicon from "../assets/images/Task.png";
import companyicon from "../assets/images/Company.png";
import projecticon from "../assets/images/Project.png";
import leadersicon from "../assets/images/blank-profile-picture-30x30.webp";

function DashboardADMIN() {

    const [Data, setData] = useState({});
    const [leadersDate, setLeadersDate] = useState([]);
    const [employeesDate, setEmployeesDDate] = useState([]);
    async function fetchDataCount() {
        try {

            const response = await fetch(BaseUrl + "api/getCountsOfAdminData", {
                method: "GET",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
            });
            const { data } = await response.json();

            setData(data[0])

         
        }
        catch (error) { console.error("error", error); }
    }
    async function fetchDataLeadersName() {
        try {

            const response = await fetch(BaseUrl + "api/getallLeadersNames", {
                method: "GET",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
            });

            const { data } = await response.json();
            setLeadersDate(data);
        }
        catch (error) { console.error("error", error); }
    }
    async function fetchDataEmployeeName() {
        try {

            const response = await fetch(BaseUrl + "api/getallemployeeNames", {
                method: "GET",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
            });

            const { data } = await response.json();

            setEmployeesDDate(data)

         
        }
        catch (error) { console.error("error", error); }
    }
    useEffect(() => {
        fetchDataCount();
        fetchDataLeadersName();
        fetchDataEmployeeName();

    }, []);
    return (
        <div className="dashborad-admin-container">
            <div className="admin-welcome-prompt">Welcome Admin,</div>
            <div className='admin-card-row'>
                <div className="admin-card-column">
                    <div className="admin-dashboard-content-left">
                        <div className="admin-dashboard-img">
                            <img className='admin-image-style' src={projecticon} alt="projecticon" />
                        </div>
                    </div>
                    <div className="admin-dashboard-content-right">
                        <div className="admin-dashboard-count">{Data.ProjectCount}</div>
                        <div className="admin-dashboard-contents">Projects</div>
                    </div>
                </div>
                <div className="admin-card-column">
                    <div className="admin-dashboard-content-left">
                        <div className="admin-dashboard-img">
                            <img src={companyicon} alt="companyicon" />
                        </div>
                    </div>
                    <div className="admin-dashboard-content-right">
                        <div className="admin-dashboard-count">{Data.CompanyCount}</div>
                        <div className="admin-dashboard-contents">Company</div>
                    </div>
                </div>
                <div className="admin-card-column">
                    <div className="admin-dashboard-content-left">
                        <div className="admin-dashboard-img">
                            <img src={taskicon} alt="taskicon" />
                        </div>
                    </div>
                    <div className="admin-dashboard-content-right">
                        <div className="admin-dashboard-count">{Data.TaskCount}</div>
                        <div className="admin-dashboard-contents">Tasks</div>
                    </div>
                </div>
                <div className="admin-card-column">
                    <div className="admin-dashboard-content-left">
                        <div className="admin-dashboard-img">
                            <img src={employeeicon} alt="employeeicon" />
                        </div>
                    </div>
                    <div className="admin-dashboard-content-right">
                        <div className="admin-dashboard-count">{Data.EmployeeCount}</div>
                        <div className="admin-dashboard-contents">Members</div>
                    </div>
                </div>  
            </div>


            {/* Leaders and Employees details */}
            <div className='admin-dashboard-full-content-TL-EM'>
                {leadersDate.length === 0 ? "" : <div className='Pl-head-container'>
                    <p className='admin-dashboard-TL-heading'>Team Leads</p>
                    <div className="admin-dashboard-entire-content">

                        {leadersDate.map((ArrayData, i) => (

                            <div className="admin-team-leaders">

                                <div className="admin-dashboard-content-bottom">
                                    <div className="admin-dashboard-leaders-img">
                                        <img src={ArrayData.ProfileImage==null? leadersicon:  ArrayData.ProfileImage} alt="Leadersicon" />
                                    </div>
                                    <div className="admin-dashboard-leaderName">{ArrayData.EmployeeName}</div>
                                </div>
                            </div>
                        ))}


                    </div>
                </div>}
                {employeesDate.length === 0 ? "" :
                    <div className='EM-head-container'>
                        <p className='admin-dashboard-TL-heading'>Team Members</p>
                        <div className='admin-dashboard-entire-content-employee'>

                            {employeesDate.map((ArrayData, i) => (

                                <div className="admin-team-members">

                                    <div className="admin-dashboard-content-bottom">
                                        <div className="admin-dashboard-leaders-img">
                                            <img src={ArrayData.ProfileImage==null? leadersicon:  ArrayData.ProfileImage} alt="Leadersicon" />
                                        </div>
                                        <div className="admin-dashboard-leaderName">{ArrayData.EmployeeName}</div>
                                    </div>
                                </div>
                            ))}


                        </div>
                    </div>}
            </div>
        </div>
    )
}

export default DashboardADMIN;