import React, { useState, useEffect } from 'react';
import '../assets/css/AssignPagination.css';
import { BaseUrl } from '../env/baseurl';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import DoneIcon from '@mui/icons-material/Done';
import TextField from '@mui/material/TextField';
import Button from "./Button.js";
import Input from "./Input.js";
import AssignTasks from './AssignTasks';
import tapimg from "../assets/images/tap.png"
import EditStatusPopup from './EditStatusPopup';
import StatusPopup from './StatusPopup';
import TouchAppIcon from '@mui/icons-material/TouchApp';
import TouchAppTwoToneIcon from '@mui/icons-material/TouchAppTwoTone';
import TouchAppOutlinedIcon from '@mui/icons-material/TouchAppOutlined';



const decipher = (salt) => {
    const textToChars = text => text.split('').map(c => c.charCodeAt(0));
    const applySaltToChar = code => textToChars(salt).reduce((a, b) => a ^ b, code);
    return encoded => encoded.match(/.{1,2}/g)
        .map(hex => parseInt(hex, 16))
        .map(applySaltToChar)
        .map(charCode => String.fromCharCode(charCode))
        .join('');
}
const myDecipher = decipher('mySecretSalt')

function getItemFromLocal(localData) {
    let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
    return form_data;

}

const AssignPagination = (props) => {

    let local_data = getItemFromLocal("user_crypt")
    const projectleaderData = {
        EmployeeID: local_data.EmployeeID,
        EmployeeName: local_data.EmployeeName
    }

    const [currentPage, setCurrentPage] = useState(1);
    const [data, setdata] = useState([]);
    const [records, setrecords] = useState([]);
    const [totalPage, settotalPage] = useState();
    const [numbers, setnumbers] = useState([]);
    const [Companies, setCompanies] = useState();
    const recordPerPage = 5;
    const lastIndex = currentPage * recordPerPage;
    const firstIndex = lastIndex - recordPerPage;
    const [activeProjectId, setactiveProjectId] = useState(null);
    const [activeProjectName, setactiveProjectName] = useState("");
    const [activeProjectDescription, setactiveProjectDescription] = useState("");
    const [hide, setHide] = useState(false);
    const [hideEdit, setHideEdit] = useState(new Set());
    /// set() consist of add , delete, has 
    const [counter, setcounter] = useState(0);
    const [status, setstatus] = useState('');
    const [newpage, setnewpage] = useState(0);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isSaved, setisSaved] = useState(false)
    const [payload, setpayload] = useState('initialState');
    const [count, setcount] = useState(0);
    const [incrementCount, setIncrementCount] = useState(0);

    const [isAssign, setisAssign] = useState(false);

    const [assignDetails, setassignDetails] = useState(null);

    const [fetchStatus, setfetchStatus] = useState(null);


        
      const handleIncrementCount = () => {
        if (count > 0) {
         
          setcount(0);
        }
      
        setIncrementCount(incrementCount + 1);
    
      };
    const callback = payload => {
  
        setfetchStatus(payload)
    }


    function prePage() {
        if (currentPage !== 1) {
            setCurrentPage(currentPage - 1);
            setnewpage(newpage - recordPerPage);
        }
    }
    function changePage(newPage) {
        if (newPage !== currentPage) {
            setCurrentPage(newPage);
            setnewpage(0);
            if (newPage > numbers[0]) {
                setnewpage(newpage + recordPerPage);
            }
            if (newPage < numbers[0]) {
                setnewpage(newpage - recordPerPage);
            }
        }
    }
    function nextPage() {
        if (currentPage !== totalPage) {
            setCurrentPage(currentPage + 1);
            setnewpage(newpage + recordPerPage);
        }
    }

    //api get function 
    async function fetchData() {
        try {
            const response = await fetch(BaseUrl + "api/getassignedtasks", {
                method: "POST",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(projectleaderData)
            });

            const { data, status } = await response.json();
            // const { status } = await response.json();

            setdata(data)
            setrecords(data.slice(firstIndex, lastIndex))
            settotalPage(Math.ceil(data.length / recordPerPage))


        }
        catch (error) { console.error("error", error); }
    }

    useEffect(() => {
        fetchData();
        setnumbers(Array.from({ length: totalPage }, (_, index) => index + 1));
    }, [currentPage, totalPage]);

    useEffect(() => {
        
        setTimeout(() => {
            fetchData();
        }, 400);
    }, [fetchStatus]);

    //api put function 
    async function updateTaskFunction(TaskUpdateParam) {
        try {
            const TaskProjectData =
            {
                TaskDescription: activeProjectDescription,
                ProjectID: TaskUpdateParam
            }
            const response = await fetch(BaseUrl + "TaskProjectData", {
                method: "put",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(TaskProjectData),
            })
            const data = await response.json();
            // const status = await response.json();
      

        }
        catch (error) { console.error("Error", error); }
    }
    

    const handleClick = () => {
        setisAssign(false)
    
    }
    const handleDone = () => {
        setisAssign(false)
        setisSaved(true);
        handleIncrementCount();
    }

    return (
        <>
           <div>
                {isSaved && (<EditStatusPopup message={"successfully Assigned!"} timeout={2000}  handleIncrementCount={handleIncrementCount}  />)}
                </div>
            {data===undefined || data.length==0 ? <div className="assign-prj-bodycontainer"><div className='assign-prj-tablecontainer'><h2>No Tasks have been assigned yet</h2></div></div> : <div className="assign-prj-bodycontainer">
                <div className='assign-prj-tablecontainer'>
                    <table className="assign-prj-tablecontent">
                        {/* <h4 className='AssignPagination-heading' >Assign Details</h4> */}
                        <thead>
                            <th className='assign-prj-tablehead'>S.No</th>
                            <th className='assign-prj-tablehead'>Project Name</th>
                            <th className='assign-prj-tablehead'>Task Name</th>
                            <th className='assign-prj-tablehead '>Description</th>
                            <th className='assign-prj-tablehead'>Duration</th>
                            <th className='assign-prj-tablehead'>Employee Name</th>
                            <th className='assign-prj-tablehead'>Assign</th>
                        </thead>
                        <tbody className='assign-prj-tablebody'>
                            {records.map((ArrayData, i) => (
                                <tr className='assign-prj-tablerow' key={i}>

                                    {/* project name  */}
                                    <td className='assign-prj-tabledata'>{i + 1 + newpage}</td>
                                    <td className='assign-prj-tabledata'>{ArrayData.ProjectName}</td>

                                    {/* Task name  */}
                                    <td className='assign-prj-tabledata'>{ArrayData.TaskName}</td>

                                    {/* project description */}
                                    <td className=' assign-prj-description'>
                                        {ArrayData.ProjectID === activeProjectId && hide ? "" : ArrayData.TaskDescription}

                                        {hide && ArrayData.ProjectID === activeProjectId && (

                                            <input
                                                defaultValue={ArrayData.TaskDescription}
                                                onChange={(e) => {
                                                    setactiveProjectDescription(e.target.value);
                                              
                                                }} />
                                        )}
                                    </td>
                                    <td className={`assign-prj-tabledata ${ArrayData.EmployeeName == null ? "assign-task-null" : " "}`}>{ArrayData.Duration == null ? "-" : ArrayData.Duration}</td>
                                    <td className={`assign-prj-tabledata ${ArrayData.EmployeeName == null ? "assign-task-null" : " "}`}>{ArrayData.EmployeeName == null ? "-" : ArrayData.EmployeeName}</td>
                                    <td className='prj-tabledata'>
                                        {/* <img src={tapimg} className="tap-icon-png-task" onClick={
                                            () => {
                                                setcount(count + 1);
                                                setisSaved(false);
                                                setisAssign(true)
                                                setassignDetails({
                                                    TaskID: ArrayData.TaskID,
                                                    ProjectName: ArrayData.ProjectName,
                                                    TaskName: ArrayData.TaskName,
                                                    TaskDescription: ArrayData.TaskDescription,
                                                    LoggedUserName: projectleaderData.EmployeeName
                                                })
                                            }
                                        }
                                        /> */}
                                            <TouchAppOutlinedIcon  sx={{ color: '#5f4d4d',fontSize: '35px',cursor: 'pointer','&:hover': {color: '#2d2828', }}} onClick={
                                            () => {
                                                setcount(count + 1);
                                                setisSaved(false);
                                                setisAssign(true)
                                                setassignDetails({
                                                    TaskID: ArrayData.TaskID,
                                                    ProjectName: ArrayData.ProjectName,
                                                    TaskName: ArrayData.TaskName,
                                                    TaskDescription: ArrayData.TaskDescription,
                                                    LoggedUserName: projectleaderData.EmployeeName
                                                })
                                            }
                                        }/>
                                    </td>

                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                {isAssign && <AssignTasks handleclick_close={handleClick} handledone_close={handleDone} assign_details={assignDetails} callback={callback} />}
             
            </div>}

            {data===undefined || data.length==0 ?"" : <div className='assign-prj-navbar'>
                <ul className='assign-prj-pagination'>
                    <li className='assign-prj-page-item'>
                        <a href='#' className='assign-prj-page-link' onClick={prePage}>Prev</a>
                    </li>
                    {
                        numbers.map((n, i) => (
                            <li className={`assign-prj-page-item ${currentPage === n ? 'active' : ''}`} key={i}>
                                <a href='#' className='assign-prj-page-link' onClick={() => changePage(n)}>{n}</a>
                            </li>
                        ))
                    }
                    <li className='assign-prj-page-item'>
                        <a href='#' className='assign-prj-page-link' onClick={nextPage}>Next</a>
                    </li>
                </ul>
            </div>}
        </>
    )



}

export default AssignPagination;