import {React, useContext} from 'react'
import "../assets/css/ConfirmStop.css"
import Button from './Button'
import AuthContext from '../../context/AuthProvider';


function ConfirmStop(props) {

    const { 
        NotifyAssignEmpID,
        NotifyAssignTaskNM,
        NotifyEMPname,
        NotifyAssignedToEmployeeID, } = useContext(AuthContext);


        const currentDate = new Date();
        const year = currentDate.getFullYear();
        const month = String(currentDate.getMonth() + 1).padStart(2, '0');
        const day = String(currentDate.getDate()).padStart(2, '0');
        const hours = String(currentDate.getHours()).padStart(2, '0');
        const minutes = String(currentDate.getMinutes()).padStart(2, '0');
        const seconds = String(currentDate.getSeconds()).padStart(2, '0');
        const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;


    const NotifyTaskCompleted = async (EmployeeID,taskname) => {
        try {
            const TaskComplete = {UserID : NotifyAssignedToEmployeeID,CreatedBy : EmployeeID, TaskName : taskname, EmployeeName : NotifyEMPname, currentTime : setFormatDateTime };
          const response = await fetch("/notifyTaskCompleted", {
            method: "post",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(TaskComplete),
          });
          const { data } = await response.json();
        } catch (error) {
          console.error("error", error);
        }
      };

    return (
        <div className='cd-model'>
            <div className='cs-container'>
                <p className='cs-text'>{`Are you sure you completed this task?`}</p>
                <div className='cs-buttons'>
                    <div className='cs-left-button'>
                        <button className='yes-submit-button' 
                        onClick={() => {
                            props.clickYes();
                            NotifyTaskCompleted(NotifyAssignEmpID,NotifyAssignTaskNM );
                        }}> Yes</button>
                    </div>
                    <div className='cs-right-button'>
                        <button className='no-submit-button' onClick={() => props.clickNo()}> No</button></div>
                </div>
            </div>
        </div>
        //   <Button type="button" Title="No" classfield={"no-submit-button"}  />
        //   <Button type="button" Title="Yes" classfield={"yes-submit-button" } onClick={props.click}/>
    )
}

export default ConfirmStop