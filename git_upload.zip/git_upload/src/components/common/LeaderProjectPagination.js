import React, { useState, useEffect, useContext } from "react";
import "../assets/css/LeaderProjectPagination.css";
import { BaseUrl } from "../env/baseurl";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import DoneIcon from "@mui/icons-material/Done";
import TextField from "@mui/material/TextField";
import Button from "./Button.js";
import Input from "./Input.js";
import moment from "moment";
import { logDOM } from "@testing-library/react";
import AuthContext from "../../context/AuthProvider";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ConfirmProjectDelete from "./ConfirmProjectDelete.js";
import projectcompleteicon from '../assets/images/projectcomplete.png'

const decipher = (salt) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const applySaltToChar = (code) =>
    textToChars(salt).reduce((a, b) => a ^ b, code);
  return (encoded) =>
    encoded
      .match(/.{1,2}/g)
      .map((hex) => parseInt(hex, 16))
      .map(applySaltToChar)
      .map((charCode) => String.fromCharCode(charCode))
      .join("");
};
const myDecipher = decipher("mySecretSalt");

function getItemFromLocal(localData) {
  let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
  return form_data;
}

const LeaderProjectPagination = (props) => {
  let local_data = getItemFromLocal("user_crypt");
  const projectleaderData = {
    EmployeeID: local_data.EmployeeID,
    EmployeeName: local_data.EmployeeName,
  };

  const [currentPage, setCurrentPage] = useState(1);
  const [data, setdata] = useState([]);
  const [datastatus, setdatastatus] = useState(false)
  const [records, setrecords] = useState([]);
  const [totalPage, settotalPage] = useState();
  const [numbers, setnumbers] = useState([]);
  const [Companies, setCompanies] = useState();
  const recordPerPage = 5;
  const lastIndex = currentPage * recordPerPage;
  const firstIndex = lastIndex - recordPerPage;
  const [activeProjectId, setactiveProjectId] = useState(null);
  const [activeProjectName, setactiveProjectName] = useState("");
  const [activeProjectDescription, setactiveProjectDescription] = useState("");
  const [hide, setHide] = useState(false);
  const [hideEdit, setHideEdit] = useState(new Set());
  const [counter, setcounter] = useState(0);
  const [status, setstatus] = useState("");
  const [newpage, setnewpage] = useState(0);
  const [isActiveDelete, setisActiveDelete] = useState(false);
  const [DifferenceDate, setDifferenceDate] = useState("");
  const [ReadData, setReadData] = useState([]);
  const {
    NotifyBadgeReadCount,
    setNotifyBadgeReadCount,
    NotificationID,
    setNotificationID,
    NotifyEMPname,
    setNotifyEMPname,
  } = useContext(AuthContext);
  const [ProjectIDStatus, setProjectIDStatus] = useState([]);
  const [ProjectCreatedByStatus, setProjectCreatedByStatus] = useState([]);
  const [ProjectNameStatus, setProjectNameStatus] = useState([]);
  const [LeaderName, setLeaderName] = useState([]);
  const [LeaderID, setLeaderID] = useState([]);

  setNotificationID(projectleaderData.EmployeeID);
  setNotifyBadgeReadCount(
    ReadData.reduce((sum, value) => sum + (value === 0), 0)
  );

  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, "0");
  const day = String(currentDate.getDate()).padStart(2, "0");
  const hours = String(currentDate.getHours()).padStart(2, "0");
  const minutes = String(currentDate.getMinutes()).padStart(2, "0");
  const seconds = String(currentDate.getSeconds()).padStart(2, "0");

  const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  const startDate = data.map((items) => items.StartDate);
  const endDate = data.map((items) => items.EndDate);

  function parseDate(dateString) {
    const [day, month, year] = dateString.split("-").reverse().map(Number);
    return new Date(year, month - 1, day);
  }
  function dateDifference(date1, date2) {
    const differences = [];
    for (let i = 0; i < date1.length; i++) {
      const startDate = parseDate(date1[i]);
      const endDate = parseDate(date2[i]);
      const diffInMilliseconds = endDate - startDate;
      const diffInDays = diffInMilliseconds / (1000 * 60 * 60 * 24);
      differences.push(Math.round(diffInDays));
      setDifferenceDate(differences);
    }
    return differences;
  }

  const FetchNotifyReadDATA = async () => {
    try {
      const NotifyReadDATA = { UserID: NotificationID };
      const response = await fetch("/fetchNotifyReadDATA", {
        method: "post",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(NotifyReadDATA),
      });
      const { data } = await response.json();
      setReadData(data === undefined ? [] : data.map((items) => items.IsRead));
    } catch (error) {
      console.error("error", error);
    }
  };

  function prePage() {
    if (currentPage !== 1) {
      setCurrentPage(currentPage - 1);
      setnewpage(newpage - recordPerPage);
    }
  }
  function changePage(newPage) {
    if (newPage !== currentPage) {
      setCurrentPage(newPage);
      setnewpage(0);
      if (newPage > numbers[0]) {
        setnewpage(newpage + recordPerPage);
      }
      if (newPage < numbers[0]) {
        setnewpage(newpage - recordPerPage);
      }
    }
  }
  function nextPage() {
    if (currentPage !== totalPage) {
      setCurrentPage(currentPage + 1);
      setnewpage(newpage + recordPerPage);
    }
  }
  function handleclick_open() {
    ProjectCompletion(ProjectIDStatus);
    NotifyProjectCompletion(
      ProjectCreatedByStatus,
      LeaderName,
      LeaderID,
      ProjectNameStatus
    );
    setisActiveDelete(false);
  }
  function handleclick_close() {
    setisActiveDelete(false);
  }
  async function fetchData() {
    try {
      const employeeIDdata = { EmployeeID: projectleaderData.EmployeeID };

      const response = await fetch("/getProjectLeadersDetails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(employeeIDdata),
      });

      const { data, status } = await response.json();
      setdata(data === undefined ? [] : data);
      setdatastatus(status==200 ? true : false);
      setrecords(data.slice(firstIndex, lastIndex));
      settotalPage(Math.ceil(data.length / recordPerPage));
    } catch (error) {
      console.error("error", error);
    }
  }

  async function ProjectCompletion(prjID) {
    try {
      const ProjectID = await { ProjectID: prjID };

      const response = await fetch("/ProjectCompletion", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(ProjectID),
      });
      const { data, status } = await response.json();
    } catch (error) {
      console.error("error", error);
    }
  }

  async function NotifyProjectCompletion(
    userID,
    LeaderName,
    LeaderID,
    prjNAME
  ) {
    try {
      const NotifyCompleteDATA = await {
        UserID: userID,
        LeaderName: LeaderName,
        CreatedBy: LeaderID,
        CreatedOn: setFormatDateTime,
        ProjectName: prjNAME,
      };

      const response = await fetch("/NotifyProjectCompletion", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(NotifyCompleteDATA),
      });
      const { data, status } = await response.json();
    } catch (error) {
      console.error("error", error);
    }
  }

  useEffect(() => {
    FetchNotifyReadDATA();
    fetchData();
    dateDifference(startDate, endDate);
    setnumbers(Array.from({ length: totalPage }, (_, index) => index + 1));
    setLeaderName(projectleaderData.EmployeeName);
    setLeaderID(projectleaderData.EmployeeID);
  }, [currentPage, totalPage, data]);

  useEffect(() => {
    setTimeout(() => {
      fetchData();
    }, 400);
  }, [props.doFetch]);
  return (
    <>
      {datastatus ? (

        <div className="leaderProject-prj-bodycontainer">
          <div className="leaderProject-prj-tablecontainer">
            <table className="leaderProject-prj-tablecontent">
              <thead>
                <th className="leaderProject-prj-tablehead">S.No</th>
                <th className="leaderProject-prj-tablehead">Project Name</th>
                <th className="leaderProject-prj-tablehead">Description</th>
                <th className="leaderProject-prj-tablehead ">Company Name</th>
                <th className="leaderProject-prj-tablehead">DeadLine</th>
                <th className="leaderProject-prj-tablehead">Action</th>
              </thead>
              <tbody className="leaderProject-prj-tablebody">
                {records.map((ArrayData, i) => (
                  <tr className="leaderProject-prj-tablerow" key={i}>
                    {/* project name  */}
                    <td className="leaderProject-prj-tabledata">
                      {i + 1 + newpage}
                    </td>
                    <td className="leaderProject-prj-tabledata">
                      {ArrayData.ProjectName}
                    </td>

                    {/* project description */}
                    <td className=" leaderProject-prj-description">
                      {ArrayData.Description}
                    </td>
                    <td className="leaderProject-prj-tabledata">
                      {ArrayData.CompanyName}
                    </td>
                    <td className="leaderProject-prj-tabledata leaderProject-prj-tabledata-Date">
                      {DifferenceDate[i] + " Days"}
                    </td>

                    <td className="leaderProject-prj-tabledata">
                      {/* <CheckCircleIcon  sx={{color:"green", margin:"5px"}}/> */}
                      <img className="projectcomplete" onClick={() => {
                        setProjectIDStatus(ArrayData.ProjectID);
                        setProjectNameStatus(ArrayData.ProjectName);
                        setProjectCreatedByStatus(ArrayData.CreatedBy);
                        setisActiveDelete(true);

                      }} title="Complete" src={projectcompleteicon} />

                      {isActiveDelete && ArrayData.isStatus === 0 && (
                        <ConfirmProjectDelete
                          clickNo={() => {
                            handleclick_close();
                          }}
                          clickYes={() => {
                            handleclick_open();
                          }}
                        />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>)
        :(
        <div className="leaderProject-prj-bodycontainer">
          <div className="leaderProject-prj-tablecontainer">
            <h2>No Projects have been created yet</h2>
          </div>
        </div>
      )}

      {data === undefined || data.length == 0 ? (
        ""
      ) : (
        <div className="leaderProject-prj-navbar">
          <ul className="leaderProject-prj-pagination">
            <li className="leaderProject-prj-page-item">
              <a
                href="#"
                className="leaderProject-prj-page-link"
                onClick={prePage}
              >
                Prev
              </a>
            </li>
            {numbers.map((n, i) => (
              <li
                className={`leaderProject-prj-page-item ${currentPage === n ? "active" : ""
                  }`}
                key={i}
              >
                <a
                  href="#"
                  className="leaderProject-prj-page-link"
                  onClick={() => changePage(n)}
                >
                  {n}
                </a>
              </li>
            ))}
            <li className="leaderProject-prj-page-item">
              <a
                href="#"
                className="leaderProject-prj-page-link"
                onClick={nextPage}
              >
                Next
              </a>
            </li>
          </ul>
        </div>
      )}
    </>
  );
};

export default LeaderProjectPagination;