import React, { useState } from 'react';
import './../assets/css/Popup.css';
import Addproject from './AddProjects';
import StatusPopup from './../common/StatusPopup';


const Popup = (props) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSaved, setisSaved] = useState(false);
  const [count, setcount] = useState(0);
  const [incrementCount, setIncrementCount] = useState(0);
  const [payload, setpayload] = useState('initialState');

  const openModal = () => {
    setIsModalOpen(true);
  };

  const callback = payload => {
    setpayload(payload)
    props.callback(payload)
  }

  const handleIncrementCount = () => {
    if (count > 0) {
      
      setcount(0);
    }
  
    setIncrementCount(incrementCount + 1);

  };

  return (
    <div>
      <button className="popup-openBtn" onClick={() => {openModal();setcount(count + 1);setisSaved(false);}}>Add Projects</button>

      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <Addproject function={()=>{setIsModalOpen(false)}} 
            close={()=>{setisSaved(true);handleIncrementCount();}}
            callback={callback}
            />
          </div>
        </div>
      )}
      {isSaved && (<StatusPopup message={"Successfully Added!"} timeout={2000}  handleIncrementCount={handleIncrementCount} />)}
    </div>
  );
};
    

export default Popup;