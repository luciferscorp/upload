import React, { useState, useEffect, useContext } from 'react'
import { useNavigate } from 'react-router-dom';
import { Alert, Space } from 'antd';
import '../../assets/css/Profile.css'
import Navbar from '../../common/Navbar'
import Sidebar from '../../common/Sidebar'
import default_profile_img from "../../assets/images/blank-profile-picture.webp"
import Input from "../../common/Input"
import Button from "../../common/Button"
import { BaseUrl } from '../../env/baseurl'
import AuthContext from "../../../context/AuthProvider";

import { Icon, IconButton } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import VisibilityIcon from '@mui/icons-material/Visibility';




const decipher = (salt) => {
    const textToChars = text => text.split('').map(c => c.charCodeAt(0));
    const applySaltToChar = code => textToChars(salt).reduce((a, b) => a ^ b, code);
    return encoded => encoded.match(/.{1,2}/g)
        .map(hex => parseInt(hex, 16))
        .map(applySaltToChar)
        .map(charCode => String.fromCharCode(charCode))
        .join('');
}
const myDecipher = decipher('mySecretSalt')

//Password Encryption
const cipher = salt => {
    const textToChars = text => text.split('').map(c => c.charCodeAt(0));
    const byteHex = n => ("0" + Number(n).toString(16)).substr(-2);
    const applySaltToChar = code => textToChars(salt).reduce((a, b) => a ^ b, code);
    return text => text.split('')
        .map(textToChars)
        .map(applySaltToChar)
        .map(byteHex)
        .join('');
}
const enCipher = cipher('mySecretSalt')

function getItemFromLocal(localData) {
    let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
    return form_data;
}

const Profile = () => {
    const userDataLocal = getItemFromLocal("user_crypt");
    let local_data = getItemFromLocal("user_crypt");
    const employeeData = {
        EmployeeID: local_data.EmployeeID,
        EmployeeName: local_data.EmployeeName
    }
    const navigate = useNavigate()



    const [userData, setUserData] = useState({});
    const [oldPassword, setoldPassword] = useState("");
    const [newPassword, setnewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [isMatchPassword, setisMatchPassword] = useState(null);

    const [showPassword, setShowPassword] = useState(false)
    const [showNewPassword, setshowNewPassword] = useState(false);
    const [showConfirmPassword, setshowConfirmPassword] = useState(false);

    const [selectedFile, setSelectedFile] = useState(null);
    const [previewUrl, setPreviewUrl] = useState('');
    const [error1, setError1] = useState();
    const [error2, setError2] = useState();
    const [error3, setError3] = useState();
    const [ReadData, setReadData] = useState([]);

    const { setNotifyBadgeReadCount,
        NotificationID, setNotificationID, } = useContext(AuthContext);

    const { setNavbarProfileImage } = useContext(AuthContext);
    const handleFileChange = (event) => {
        event.preventDefault()
       
        const file = event.target.files[0];
        setSelectedFile(file);
        
        file == undefined ? setPreviewUrl(default_profile_img) : setPreviewUrl(URL.createObjectURL(file));
    };

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    const toggleNewPasswordVisibility = () => {
        setshowNewPassword(!showNewPassword);
    };

    const toggleConfirmPasswordVisibility = () => {
        setshowConfirmPassword(!showConfirmPassword);
    };

    setNotificationID(employeeData.EmployeeID);
    setNotifyBadgeReadCount(ReadData.reduce((sum, value) => sum + (value === 0), 0));

    const FetchNotifyReadDATA = async () => {
        try {
            const NotifyReadDATA = { UserID: NotificationID };
            const response = await fetch("/fetchNotifyReadDATA", {
                method: "post",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(NotifyReadDATA),
            });
            const { data } = await response.json();
            setReadData(data === undefined ? [] : data.map((items) => (items.IsRead)));

        } catch (error) {
            console.error("error", error);
        }
    };

    function validatePassword(password) {
        //Password length should be at least 8 characters
        if (password.length < 8) {
            return "Password must be at least 8 characters long";
        }
        //Password should contain at least one uppercase letter
        if (!/[A-Z]/.test(password)) {
            return "Password must contain at least one uppercase letter";
        }
        //Password should contain at least one lowercase letter
        if (!/[a-z]/.test(password)) {
            return "Password must contain at least one lowercase letter";
        }
        //Password should contain at least one digit
        if (!/\d/.test(password)) {
            return "Password must contain at least one digit";
        }
        //Password should contain at least one special character
        if (!/[^a-zA-Z0-9]/.test(password)) {
            return "Password must contain at least one special character";
        }
        //Password is valid
        return true;
    }

    const RedirectTODashboard = () => {
        const { Role } = userDataLocal;
        if (Role == 1) {
            navigate("/dashboard")
        } else if (Role == 2) {
            navigate("/dashboardPM")
        } else if (Role == 3) {
            navigate("/dashboardpl")
        } else {
            navigate("/dashboardEM")
        }
    }

    async function fetchEmployeeDetails() {
        const EmployeeData = { EmployeeID: userDataLocal.EmployeeID };
        try {
            const response = await fetch(BaseUrl + "api/getemployeeprofiledetails", {
                method: "post",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(EmployeeData),
            });
            const { data, status } = await response.json();
            setUserData(data[0]);
           

            return data;
        } catch (error) {
            console.error("error", error);
        }
    }

    async function fetchChangePassword(newPasswd) {
        const EmployeeData = {
            EmployeeID: userDataLocal.EmployeeID,
            EncryptedNewPassword: newPasswd
        };
        try {
            const response = await fetch(BaseUrl + "api/changepassword", {
                method: "put",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(EmployeeData),
            });
            const { data, status } = await response.json();
            // setUserData(data[0]);
          

        } catch (error) {
            console.error("error", error);
        }
    }


    //To send the uploaded image to server
    async function fetchUploadProfileImage(event) {
      
        const EmployeeData = {
            EmployeeID: userDataLocal.EmployeeID,

        }
        event.preventDefault()
        const formData = new FormData();
        selectedFile != null ? formData.append('image', selectedFile) : formData.append('resetProfile', JSON.stringify({ path: "..\\static\\media\\blank-profile-picture.efadb13dba95b5bc918b.webp" }))
       
        formData.append('jsonData', JSON.stringify(EmployeeData));
      
        try {
            const response = await fetch(BaseUrl + "api/profile_image_upload", {
                method: "post",
                body: formData,

            });
            const { status } = await response.json();

        } catch (error) {
            console.error("error", error);
        }
        setNavbarProfileImage(null)
        fetchEmployeeDetails()
        // RedirectTODashboard()
    }

    //To send the uploaded image to server
    async function fetchCheckOldPassword() {
        
        const EmployeeData = {
            EmployeeID: userDataLocal.EmployeeID,
            Email: userDataLocal.Email,
            Password: enCipher(oldPassword),
        }

        try {
            const response = await fetch(BaseUrl + "api/login", {
                method: "post",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(EmployeeData),
            });
            const { status } = await response.json();
            setisMatchPassword(status)
         
            return status;

        } catch (error) {
            console.error("error", error);
        }

        // fetchEmployeeDetails()
    }

    useEffect(() => {
        FetchNotifyReadDATA();
        fetchEmployeeDetails()
            .then((data) => {
                setPreviewUrl(data[0].ProfileImage == null ? default_profile_img : data[0].ProfileImage)
                setNavbarProfileImage(data[0].ProfileImage == null ? null : data[0].ProfileImage)

            })
    }, [ReadData]);



    const clickSaveChange = (event) => {
        fetchCheckOldPassword();
        if (newPassword == "" && confirmPassword == "" && oldPassword == "") {
            if (selectedFile != null || previewUrl == "/static/media/blank-profile-picture.efadb13dba95b5bc918b.webp") {
                fetchUploadProfileImage(event)
            }
           
            setError1("")
            setError2("")
            setError3("")
        } else if (oldPassword == "") {
            setError3("Enter your current password")
            setError1("")
        } else if (newPassword == "") {
            setError1("Enter your new password")
            setError3("")
        } else if (validatePassword(newPassword) != true) {
            //Password Validation Point
            setError1(validatePassword(newPassword))
            setError2("")
            setError3("")
        } else if (confirmPassword == "") {
            setError1("")
            setError3("")
            setError2("Re-enter your password")
        } else if (newPassword != confirmPassword) {
            setError1("")
            setError3("")
            setError2("New Password doesn't match")
        } else {
            fetchCheckOldPassword()
            setError1("")
            setError2("")
            setError3("")

            console.log("Big func", fetchCheckOldPassword().then((status) => {
                if (status != 200) {
                    setError3("Invalid current password")
                } else {

                    fetchChangePassword(enCipher(confirmPassword))

                    setConfirmPassword("")
                    setnewPassword("")
                    if (selectedFile != null || previewUrl == "/static/media/blank-profile-picture.efadb13dba95b5bc918b.webp") {
                        fetchUploadProfileImage(event)
                    }

                    localStorage.removeItem("user_crypt")
                    navigate("/login")
                }
            }))
        }
    }


    return (
        <div>
            
            <div className="popup-alert-conainter">
              { error3 =="Invalid current password" ? <div className="popup-alert-warning">
                    <Space
                        direction="vertical"
                        style={{
                            width: '100%',
                      
                        }}
                    >
                        <Alert
                            message="Warning"
                            description="Invalid current password."
                            type="warning"
                            showIcon
                            closable
                        />
                    </Space>
                </div> :
                
                <>
                </>
                }
            </div>

            <div className="profilepage-container">


                <div className="profile-content">
                    <div className="profile-img-section">
                        <img src={previewUrl} className='profile-img' />
                        <div className="profile-file-upload">
                            <label for="inputTag" className='submit-button-upload-image'>
                                Upload New Image
                                <input id="inputTag" onChange={handleFileChange} accept='image/*' type="file" />
                            </label>
                            <label for="inputTag" className='clear-button-upload-image'>
                                <IconButton sx={{ color: "#DC3545" }}>
                                    <DeleteIcon sx={{
                                        cursor: "pointer",
                                        // marginLeft: "0px",
                                        marginTop: "0px",
                                    }} onClick={() => {

                                        setPreviewUrl(default_profile_img)
                                      
                                    }} /></IconButton>
                                {/* <input id="inputTag" onChange={handleFileChange} accept='image/*' type="file" /> */}
                            </label>

                            {/* <div className='clear-profile-image'>D</div> */}
                        </div>
                        <div className="profile-username">{userData.EmployeeName}</div>
                        <div className="profile-user-email">{userData.Email}</div>
                    </div>
                    <div className="profile-details-section">
                        <div className="profile-details-section-col1">
                            <div className="profile-name">
                                Name
                            </div>
                            <div className="profile-email">
                                Email
                            </div>
                            <div className="profile-user-role">
                                Role
                            </div>
                            <div className="profile-joining-date">
                                Joining Date
                            </div>
                            <div className="profile-change-password-text">
                                Change Password
                            </div>
                        </div>
                        <div className="profile-details-section-col2">
                            <div className="profile-details-value">
                                <div className="profile-name">
                                    {userData.EmployeeName}
                                </div>
                                <div className="profile-email">
                                    {userData.Email}
                                </div>
                                <div className="profile-user-role">
                                    {userData.RoleName}
                                </div>
                                <div className="profile-joining-date">
                                    {userData.JoiningDate == null ? "-" : userData.JoiningDate}
                                </div>
                            </div>

                            <div className="profile-change-password profile-details-error-prompt">
                                <div className="profile-old-password">
                                    <Input type={showPassword ? "text" : "password"} id="password"
                                        value={oldPassword}
                                        onChange={(e) => { setoldPassword(e.target.value) }}
                                        name="password" maxLength='30'
                                        classfield="inputField-password"
                                        placeholder="Current Password"
                                    />
                                    <i className="profile-eye-icon" onClick={togglePasswordVisibility}>
                                        {showPassword ? <VisibilityIcon sx={{ color: "gray" }} /> : <VisibilityOffIcon sx={{ color: "gray" }} />}
                                    </i>
                                    <span className='profile-error1'>{error3}</span>
                                </div>
                                <div className="profile-new-password">
                                    <Input type={showNewPassword ? "text" : "password"} id="password"
                                        value={newPassword}
                                        onChange={(e) => { setnewPassword(e.target.value) }}
                                        name="password" maxLength='30'
                                        classfield="inputField-password"
                                        placeholder="New Password"
                                    />
                                    <i className="profile-eye-icon" onClick={toggleNewPasswordVisibility}>
                                        {showNewPassword ? <VisibilityIcon sx={{ color: "gray" }} /> : <VisibilityOffIcon sx={{ color: "gray" }} />}
                                    </i>
                                    <span className='profile-error1'>{error1}</span>
                                </div>
                                <div className="profile-confirm-newpassword">
                                    <Input type={showConfirmPassword ? "text" : "password"} id="password"
                                        value={confirmPassword}
                                        onChange={(e) => { setConfirmPassword(e.target.value) }}
                                        name="password" maxLength='30' classfield="inputField-password"
                                        placeholder="Re-enter new Password"
                                    />
                                    <i className="profile-eye-icon" onClick={toggleConfirmPasswordVisibility}>
                                        {showConfirmPassword ? <VisibilityIcon sx={{ color: "gray" }} /> : <VisibilityOffIcon sx={{ color: "gray" }} />}
                                    </i>
                                    <span className='profile-error1'>{error2}</span>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div className="profile-submit-button">
                    <Button type="button" Title="Save Change" onClick={(event) => clickSaveChange(event)} classfield={"submit-button-save-change"} />
                </div>
            </div>

            <div>
                <Navbar />
                <Sidebar />
            </div>

        </div>
    )
}

export default Profile;