import React, { useState ,useContext} from 'react'
import CompanyPagination from '../../common/CompanyPagination'
import CompPopup from '../../common/CompPopup'
import Navbar from '../../common/Navbar'
import NotifiPopup from '../../common/Notification_Popup'
import Pagination from '../../common/Pagination'
import Sidebar from '../../common/Sidebar'
import AuthContext from '../../../context/AuthProvider'
import Footer from '../../common/footer'


function Company() {

 const [fetchStatus, setfetchStatus] = useState(null);
 const { NotifyBadgeReadCount, setNotifyBadgeReadCount,
  DB_ProjectMGR_OpenTasks, setDB_ProjectMGR_OpenTasks, } = useContext(AuthContext);
setNotifyBadgeReadCount(0);
  const callback = payload => {
   
    setfetchStatus(payload)
  }

  return (
    <>
      <div className='home-body'>
        <Navbar />
        <Sidebar role="admin" />
        <CompPopup title="Add Company" callback={callback} />
        <CompanyPagination doFetch={fetchStatus} />
        <div className="report-footer">
                <Footer/>
                </div>
      </div>
    </>
  )
}

export default Company;