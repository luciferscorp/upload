import React, { useState, useContext, useEffect } from 'react'
import '../../assets/css/Home.css'
import Navbar from '../../common/Navbar'
import Sidebar from '../../common/Sidebar'
import ProjectsPopup from '../../common/ProjectsPopup'
import ProjectPagination from '../../common/ProjectsPagination'
import AuthContext from '../../../context/AuthProvider'
import Footer from '../../common/footer'
import { BaseUrl } from '../../env/baseurl'

function Projects() {

  const decipher = (salt) => {
    const textToChars = text => text.split('').map(c => c.charCodeAt(0));
    const applySaltToChar = code => textToChars(salt).reduce((a,b) => a ^ b, code);
    return encoded => encoded.match(/.{1,2}/g)
      .map(hex => parseInt(hex, 16))
      .map(applySaltToChar)
      .map(charCode => String.fromCharCode(charCode))
      .join('');
  }
    const myDecipher =  decipher('mySecretSalt')
  
  function getItemFromLocal(localData) {
    let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
    return form_data;
    
  }
  
    let local_data = getItemFromLocal("user_crypt");
    const LoggedID = {EmployeeID: local_data.EmployeeID}

    const [ReadData, setReadData] = useState([]);


  const [fetchStatus, setfetchStatus] = useState(null);
  const [isCompanyRecords, setisCompanyRecords] = useState(false);
  const { NotifyBadgeReadCount, setNotifyBadgeReadCount,
    DB_ProjectMGR_OpenTasks, setDB_ProjectMGR_OpenTasks, 
    NotificationID, setNotificationID} = useContext(AuthContext);
    setNotificationID(LoggedID.EmployeeID);
    setNotifyBadgeReadCount(ReadData.reduce((sum, value) => sum + (value === 0), 0));
  
  const callback = payload => {
    
    setfetchStatus(payload)
  }

  const FetchNotifyReadDATA = async () => {
    try {
        const NotifyReadDATA = { UserID: NotificationID };
        const response = await fetch("/fetchNotifyReadDATA", {
            method: "post",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(NotifyReadDATA),
        });
        const { data } = await response.json();
        setReadData(data===undefined ? [] : data.map((items) => (items.IsRead)));

    } catch (error) {
        console.error("error", error);
    }
};
FetchNotifyReadDATA();
  //api get function 
  async function fetchData() {
    try {
      const response = await fetch(BaseUrl + "api/company/getallactivecompanies", {
        method: "GET",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
      });

      const { status } = await response.json();
      //  return "status";
      setisCompanyRecords(status===300?false:true)

    }
    catch (error) { console.error("error", error); }
  }

  useEffect(() => {
    fetchData()
  

  }, []);


  return (
    <>
      <div className='home-body'>

        
        <Sidebar />
        {isCompanyRecords &&
          <ProjectsPopup callback={callback} />
        }

        <ProjectPagination doFetch={fetchStatus} />
        <div className="report-footer">
          <Footer />
        </div>
        <Navbar />
      </div>
    </>
  )
}

export default Projects;