import AdminReportPagination from '../../common/AdminReportPagination'
//  import DownloadPDF from '../../common/DownloadPDF'
import Navbar from '../../common/Navbar'
import Sidebar from '../../common/Sidebar'
import Footer from '../../common/footer'
import React, { useState,useContext } from 'react'

import AuthContext from "../../../context/AuthProvider";

export default function Report() {

    const { NotifyBadgeReadCount, setNotifyBadgeReadCount} = useContext(AuthContext);
  setNotifyBadgeReadCount(0);

    // const [payload, setpayload] = useState("initialState");
    // const callbacktable = payload => {
    //     setpayload(payload)
    // }

    return (
        <>
            <div>
                <Navbar />
                
                <Sidebar />
                {/* <DownloadPDF tobedownloaded={payload} /> */}

                {/* <DashBoardPagination callbacktable={callbacktable} /> */}

                <AdminReportPagination/>
                <div className="report-footer">
                <Footer/>
                </div>

            </div>
        </>
    )
}