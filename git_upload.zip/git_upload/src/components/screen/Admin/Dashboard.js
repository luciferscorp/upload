import AdminReportPagination from '../../common/AdminReportPagination'
//  import DownloadPDF from '../../common/DownloadPDF'
import Navbar from '../../common/Navbar'
import Sidebar from '../../common/Sidebar'
import Footer from '../../common/footer'
import React, { useState, useContext } from 'react'

import AuthContext from "../../../context/AuthProvider";
import DashboardADMIN from '../../common/DashboardADMIN';

export default function DashBoard() {

    const { NotifyBadgeReadCount, setNotifyBadgeReadCount } = useContext(AuthContext);
    setNotifyBadgeReadCount(0);


    return (
        <>
            <div>
                <Navbar />
                <Sidebar />
                <DashboardADMIN />
                <div className="report-footer">
                <Footer/>
                </div>

            </div>
        </>
    )
}