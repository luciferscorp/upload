import React, { useState, useContext, useEffect } from 'react';
import '../../assets/css/Home.css';
import Navbar from '../../common/Navbar';
import Sidebar from '../../common/Sidebar';
import AssignPagePopup from '../../common/AssignPagePopup';
import AssignPagination from '../../common/AssignPagination';
import AuthContext from "../../../context/AuthProvider";
import Footer from '../../common/footer'
const decipher = (salt) => {
  const textToChars = text => text.split('').map(c => c.charCodeAt(0));
  const applySaltToChar = code => textToChars(salt).reduce((a,b) => a ^ b, code);
  return encoded => encoded.match(/.{1,2}/g)
    .map(hex => parseInt(hex, 16))
    .map(applySaltToChar)
    .map(charCode => String.fromCharCode(charCode))
    .join('');
}
  const myDecipher =  decipher('mySecretSalt')

function getItemFromLocal(localData) {
  let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
  return form_data;
  
}

function Assign() {

  let local_data = getItemFromLocal("user_crypt")
  const projectleaderData = {
      EmployeeID: local_data.EmployeeID,
      EmployeeName : local_data.EmployeeName
  }

  const [fetchStatus, setfetchStatus] = useState(null);
  const [ReadData, setReadData] = useState([]);
  const { NotifyBadgeReadCount, setNotifyBadgeReadCount, NotificationID, setNotificationID,NotifyEMPname, setNotifyEMPname,} = useContext(AuthContext);
 
  setNotificationID(projectleaderData.EmployeeID);
  setNotifyBadgeReadCount(ReadData.reduce((sum, value) => sum + (value === 0), 0));

useEffect(()=>{
  const FetchNotifyReadDATA = async () => {
    try {
        const NotifyReadDATA = {UserID : NotificationID};
      const response = await fetch("/fetchNotifyReadDATA", {
        method: "post",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(NotifyReadDATA),
      });
      const { data } = await response.json();
      setReadData(data===undefined ? [] : data.map((items) => (items.IsRead)));
      
    } catch (error) {
      console.error("error", error);
    }
  };
  FetchNotifyReadDATA();
},[ReadData])

  const callback = payload => {
  
    setfetchStatus(payload)
  }
  
  return (
    <>
    <div className='home-body'>

      <Navbar />
      <Sidebar />
      {/* <AssignPagePopup title="Assign" callback={callback} /> */}
      <AssignPagination doFetch={fetchStatus}/>
      <div className="report-footer">
                <Footer/>
                </div>
    </div>
    </>
  )
}

export default Assign;