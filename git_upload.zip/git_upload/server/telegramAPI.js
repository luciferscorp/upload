const express = require("express");
const sqlite3 = require("sqlite3");
const cors = require("cors");
const PORT = 8080;
const { handler,not_a_mem_handler} = require("./controller");
const app = express();
app.use(express.json());

const corsOptions = {
  origin: "http://localhost:3000",
};
app.use(cors(corsOptions));
app.use(cors());

let db = new sqlite3.Database("workpulse.db", sqlite3.OPEN_READWRITE, (err) => {
  if (err) return console.error(err);
});

async function getEmployees() {
  const sql = "select *,(select RoleName from roles where RoleId = e.Role) as rolename from Employee e where Role != 1";
  return new Promise((resolve, reject) => {
    db.all(sql, [], (err, rows) => {
      if (err) reject(err);
      resolve(rows);
    });
  });
}
async function getCompanies() {
  const sql = "select * from Company";
  return new Promise((resolve, reject) => {
    db.all(sql, [], (err, rows) => {
      if (err) reject(err);
      resolve(rows);
    });
  });
}
async function getProjects() {
  const sql = "select * from Projects";
  return new Promise((resolve, reject) => {
    db.all(sql, [], (err, rows) => {
      if (err) reject(err);
      resolve(rows);
    });
  });
}
app.post("*", async (req, res) => {
  const data = req.body;
  const Not_a_MemberMessage = "You're not a member";
  try {
    const employees = await getEmployees();
    const companies = await getCompanies();
    const projects = await getProjects();
    console.log("Status : ", data.message.text);
    if(data.message.chat.username=='shiva2002_1008'){
    res.send(await handler(req, "POST", employees,companies,projects)); }
    else{
      res.send(await not_a_mem_handler(req, "POST", Not_a_MemberMessage));
    }
  } catch (error) {
    res.json({ status: 400, success: false });
  }
});

app.get("*", async (req, res) => {
  console.log("GET request");
  res.send(await handler(req, "GET"));
});

app.listen(PORT, function (err) {
  if (err) console.log(err);
  console.log("Server listening on PORT", PORT);
});